"""
Módulo base del paquete de loaders.

Responsabilidad única: definir el contrato que todo loader debe cumplir
(`BaseLoader`) y la lógica común a los loaders que leen desde un archivo
en disco (`FileLoader`).

IMPORTANTE — límite de responsabilidad de este módulo y de todo el
paquete `loaders`: un loader solo convierte una fuente (archivo o texto
pegado) en texto plano. Ningún loader busca EPS, Revenue, Guidance ni
ningún otro dato financiero, y ninguno aplica reglas de negocio. Esa
lógica vive en el parser financiero (todavía no construido), nunca acá.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path


class LoaderError(Exception):
    """Se lanza cuando un loader no puede convertir su fuente a texto."""


class BaseLoader(ABC):
    """
    Contrato común a todos los loaders del sistema.

    `ABC` (Abstract Base Class, "clase base abstracta") es una clase que
    no se puede instanciar directamente — solo sirve como molde para
    que otras clases hereden de ella. `@abstractmethod` marca un método
    que toda subclase está OBLIGADA a implementar; si no lo hace,
    Python tira un error apenas intentás crear el objeto, no recién
    cuando lo usás. Así nos aseguramos de que ningún loader nuevo se
    "olvide" de implementar `load()`.
    """

    @abstractmethod
    def load(self) -> str:
        """
        Devuelve el contenido de la fuente como texto plano.

        Cada subclase decide de dónde saca ese texto (un PDF, un DOCX,
        texto pegado a mano, etc.), pero todas devuelven lo mismo: un
        `str`. Eso es lo que le permite al resto del sistema tratarlas
        de forma intercambiable.
        """
        raise NotImplementedError


class FileLoader(BaseLoader):
    """
    Loader base para todas las fuentes que son un archivo en disco
    (PDF, PPTX, DOCX, TXT).

    Esta clase implementa el "esqueleto" común a los cuatro (patrón
    Template Method): validar que el archivo existe, pedirle a la
    subclase que extraiga el texto, y verificar que no haya quedado
    vacío. Cada subclase concreta (`PDFLoader`, `PPTXLoader`, etc.)
    solo tiene que implementar `_extract_text()` con la lógica
    específica de su formato — no necesita repetir la validación.
    """

    def __init__(self, file_path: Path) -> None:
        self.file_path = Path(file_path)

    def load(self) -> str:
        self._validate_file()
        text = self._extract_text()
        text = text.strip()
        if not text:
            raise LoaderError(
                f"No se pudo extraer texto de '{self.file_path.name}': "
                "el archivo parece estar vacío o no contiene texto "
                "extraíble (por ejemplo, un PDF escaneado como imagen)."
            )
        return text

    def _validate_file(self) -> None:
        """Chequeos comunes antes de intentar leer cualquier archivo."""
        if not self.file_path.exists():
            raise LoaderError(f"El archivo no existe: {self.file_path}")
        if not self.file_path.is_file():
            raise LoaderError(
                f"La ruta no corresponde a un archivo: {self.file_path}"
            )

    @abstractmethod
    def _extract_text(self) -> str:
        """
        Lógica de extracción específica de cada formato.

        Cada subclase la implementa usando la librería que corresponda
        (pdfplumber para PDF, python-docx para DOCX, etc.). No hace
        falta validar que el archivo exista acá: `load()` ya lo hizo
        antes de llamar a este método.
        """
        raise NotImplementedError
