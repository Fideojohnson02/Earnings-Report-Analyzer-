"""Paquete de loaders: convierten cada formato de entrada en texto plano."""
