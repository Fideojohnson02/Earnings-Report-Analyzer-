"""
Loader de presentaciones PowerPoint (.pptx).

Responsabilidad única: convertir una presentación en texto plano,
preservando estructura nativa:

  - Orden de diapositivas (cada una se marca con un separador).
  - El título de cada diapositiva, marcado como encabezado ("# ...")
    — PowerPoint sí guarda cuál shape es el título, así que esto no
    es una heurística: es metadata real del archivo.
  - Tablas dentro de una diapositiva, extraídas por separado.

No interpreta el contenido de ninguna forma.
"""

from __future__ import annotations

from pptx import Presentation

from src.loaders.base_loader import FileLoader, LoaderError


class PPTXLoader(FileLoader):
    """Extrae el texto de una presentación PowerPoint (.pptx)."""

    def _extract_text(self) -> str:
        try:
            presentation = Presentation(str(self.file_path))
        except Exception as exc:
            raise LoaderError(
                f"No se pudo leer el PPTX '{self.file_path.name}': {exc}"
            ) from exc

        slide_blocks = [
            self._extract_slide(slide, slide_number)
            for slide_number, slide in enumerate(presentation.slides, start=1)
        ]
        return "\n\n".join(slide_blocks)

    def _extract_slide(self, slide, slide_number: int) -> str:
        lines = [f"--- Slide {slide_number} ---"]

        title_shape = slide.shapes.title
        title_shape_id = title_shape.shape_id if title_shape is not None else None
        if title_shape is not None and title_shape.has_text_frame:
            title_text = title_shape.text_frame.text.strip()
            if title_text:
                lines.append(f"# {title_text}")

        for shape in slide.shapes:
            # El título ya se agregó arriba, marcado como encabezado;
            # lo saltamos acá para no duplicarlo como texto normal.
            if title_shape_id is not None and shape.shape_id == title_shape_id:
                continue

            if shape.has_text_frame:
                lines.extend(self._extract_text_frame(shape))

            if shape.has_table:
                lines.append(self._extract_table_as_text(shape.table))

        return "\n".join(lines)

    def _extract_text_frame(self, shape) -> list[str]:
        lines = []
        for paragraph in shape.text_frame.paragraphs:
            # Un párrafo puede tener varios "runs" (fragmentos con
            # distinto formato: negrita, color, etc.). Los unimos para
            # reconstruir la línea completa.
            line = "".join(run.text for run in paragraph.runs)
            if line.strip():
                lines.append(line)
        return lines

    def _extract_table_as_text(self, table) -> str:
        rows_text = ["[Tabla]"]
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            rows_text.append(" | ".join(cells))
        return "\n".join(rows_text)
