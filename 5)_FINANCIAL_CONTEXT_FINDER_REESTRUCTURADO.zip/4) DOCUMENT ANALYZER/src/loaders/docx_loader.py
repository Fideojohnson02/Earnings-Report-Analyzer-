"""
Loader de documentos Word (.docx).

Responsabilidad única: convertir un documento Word en texto plano,
preservando estructura nativa:

  - Orden real del contenido: párrafos y tablas se recorren en el
    mismo orden en que aparecen en el documento (Word permite
    intercalar texto y tablas libremente; si los procesáramos por
    separado —primero todos los párrafos, después todas las
    tablas— perderíamos ese orden).
  - Títulos: si un párrafo usa un estilo de encabezado de Word
    ("Heading 1", "Heading 2", "Title", etc.), se marca con "# " —
    de nuevo, es metadata real del documento, no una heurística.
  - Tablas simples, con celdas separadas por " | ".

No interpreta el contenido de ninguna forma.
"""

from __future__ import annotations

from docx import Document
from docx.oxml.ns import qn
from docx.table import Table
from docx.text.paragraph import Paragraph

from src.loaders.base_loader import FileLoader, LoaderError

_HEADING_STYLE_PREFIXES = ("Heading", "Title")


def _iter_block_items(document):
    """
    Recorre el cuerpo del documento en su orden real, devolviendo cada
    elemento como `Paragraph` o `Table` según corresponda.

    `python-docx` expone `document.paragraphs` y `document.tables` por
    separado, cada uno en su propio orden interno — pero no en el
    orden combinado real del documento. Esta función recorre el XML
    del cuerpo del documento directamente (`document.element.body`) y
    reconstruye cada hijo como el objeto de alto nivel que le
    corresponde, respetando el orden con el que fueron escritos.
    """
    for child in document.element.body.iterchildren():
        if child.tag == qn("w:p"):
            yield Paragraph(child, document)
        elif child.tag == qn("w:tbl"):
            yield Table(child, document)


class DOCXLoader(FileLoader):
    """Extrae el texto de un documento Word (.docx)."""

    def _extract_text(self) -> str:
        try:
            document = Document(str(self.file_path))
        except Exception as exc:
            raise LoaderError(
                f"No se pudo leer el DOCX '{self.file_path.name}': {exc}"
            ) from exc

        lines: list[str] = []
        table_counter = 0

        for block in _iter_block_items(document):
            if isinstance(block, Paragraph):
                text = block.text.strip()
                if not text:
                    continue
                if self._is_heading(block):
                    lines.append(f"# {text}")
                else:
                    lines.append(text)
            elif isinstance(block, Table):
                table_counter += 1
                lines.append(self._extract_table_as_text(block, table_counter))

        return "\n".join(lines)

    def _is_heading(self, paragraph: Paragraph) -> bool:
        style_name = paragraph.style.name if paragraph.style else ""
        return any(
            style_name.startswith(prefix) for prefix in _HEADING_STYLE_PREFIXES
        )

    def _extract_table_as_text(self, table: Table, table_number: int) -> str:
        rows_text = [f"[Tabla {table_number}]"]
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            row_text = " | ".join(cells)
            if row_text.strip(" |"):
                rows_text.append(row_text)
        return "\n".join(rows_text)
