"""
Fábrica de loaders.

Responsabilidad única: dado un archivo (por su extensión) o texto
pegado, devolver la instancia del loader correcto — sin que el código
que llama tenga que saber que existen cinco clases distintas.

Este es el único lugar del sistema que necesita conocer la lista
completa de loaders disponibles. Agregar un formato nuevo en el futuro
(por ejemplo, .rtf) significa: crear la clase del loader y agregar una
línea acá — nada más se modifica.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Type

from src.loaders.base_loader import BaseLoader, FileLoader, LoaderError
from src.loaders.docx_loader import DOCXLoader
from src.loaders.pdf_loader import PDFLoader
from src.loaders.pptx_loader import PPTXLoader
from src.loaders.raw_text_loader import RawTextLoader
from src.loaders.txt_loader import TXTLoader

# Relación entre extensión de archivo y la clase de loader que sabe
# leerlo. Es un diccionario de clase, no de instancia: guarda la clase
# en sí (para poder crear un objeto nuevo cada vez), no un loader ya
# construido.
_EXTENSION_TO_LOADER: Dict[str, Type[FileLoader]] = {
    ".pdf": PDFLoader,
    ".pptx": PPTXLoader,
    ".docx": DOCXLoader,
    ".txt": TXTLoader,
}


def get_loader_for_file(file_path: Path) -> BaseLoader:
    """
    Devuelve el loader correcto para un archivo, según su extensión.

    Lanza `LoaderError` si la extensión no está soportada, en vez de
    dejar que el error aparezca más adelante en el proceso.
    """
    file_path = Path(file_path)
    suffix = file_path.suffix.lower()

    loader_cls = _EXTENSION_TO_LOADER.get(suffix)
    if loader_cls is None:
        supported = ", ".join(sorted(_EXTENSION_TO_LOADER))
        raise LoaderError(
            f"Extensión no soportada: '{suffix}'. "
            f"Formatos soportados actualmente: {supported}."
        )

    return loader_cls(file_path)


def get_loader_for_pasted_text(text: str) -> BaseLoader:
    """Devuelve el loader correspondiente a texto pegado directamente."""
    return RawTextLoader(text)
