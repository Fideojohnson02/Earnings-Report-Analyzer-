"""
Loader de texto pegado directamente por el usuario (sin archivo).

Responsabilidad única: envolver un string ya existente para que
cumpla el mismo contrato (`BaseLoader`) que los loaders de archivo,
sin interpretar su contenido de ninguna forma.
"""

from __future__ import annotations

from src.loaders.base_loader import BaseLoader, LoaderError


class RawTextLoader(BaseLoader):
    """
    Loader para texto que el usuario copia y pega directamente,
    sin pasar por un archivo.

    A diferencia de los demás loaders, no hereda de `FileLoader`
    (no hay ningún archivo que validar): hereda directo de
    `BaseLoader`, que es el único requisito real — tener un método
    `load()` que devuelva texto.
    """

    def __init__(self, text: str) -> None:
        self._text = text

    def load(self) -> str:
        text = (self._text or "").strip()
        if not text:
            raise LoaderError("El texto pegado está vacío.")
        return text
