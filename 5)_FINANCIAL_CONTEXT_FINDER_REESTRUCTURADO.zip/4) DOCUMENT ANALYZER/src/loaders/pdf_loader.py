"""
Loader de archivos PDF.

Responsabilidad única: convertir un PDF en texto plano, preservando la
mayor cantidad posible de estructura nativa del documento:

  - Orden de páginas (cada página se marca con un separador).
  - Saltos de línea dentro de cada página (los respeta pdfplumber).
  - Tablas simples con bordes detectables, extraídas por separado y
    marcadas claramente.

No interpreta el contenido de ninguna forma: no busca EPS, Revenue ni
ningún otro dato financiero. Tampoco "limpia" el texto (eso, junto con
la detección de títulos por tamaño de fuente en PDFs sin metadata de
encabezados, es responsabilidad del módulo Extractor de texto, que
viene después).
"""

from __future__ import annotations

import pdfplumber

from src.loaders.base_loader import FileLoader, LoaderError


class PDFLoader(FileLoader):
    """Extrae el texto de un archivo PDF usando la librería pdfplumber."""

    def _extract_text(self) -> str:
        try:
            with pdfplumber.open(self.file_path) as pdf:
                page_blocks = [
                    self._extract_page(page, page_number)
                    for page_number, page in enumerate(pdf.pages, start=1)
                ]
        except Exception as exc:
            # Cualquier error de la librería (archivo corrupto, PDF
            # protegido con contraseña, etc.) lo traducimos a nuestro
            # propio tipo de error, para que el resto del sistema solo
            # tenga que saber manejar `LoaderError`.
            raise LoaderError(
                f"No se pudo leer el PDF '{self.file_path.name}': {exc}"
            ) from exc

        return "\n\n".join(page_blocks)

    def _extract_page(self, page, page_number: int) -> str:
        """
        Arma el bloque de texto de una página: un separador con el
        número de página (preserva el orden del contenido), el texto
        de la página tal como lo entrega pdfplumber (que ya respeta
        los saltos de línea originales), y las tablas detectadas en
        esa página, si las hay.
        """
        parts = [f"--- Página {page_number} ---"]

        text = page.extract_text() or ""
        if text:
            parts.append(text)

        tables_text = self._extract_tables_as_text(page)
        if tables_text:
            parts.append(tables_text)

        return "\n".join(parts)

    def _extract_tables_as_text(self, page) -> str:
        """
        Extrae las tablas con bordes detectables de una página y las
        representa como texto simple, con celdas separadas por " | ".

        Nota / limitación conocida: pdfplumber suele incluir el texto
        de la tabla también dentro de `extract_text()`, así que el
        contenido de la tabla puede aparecer duplicado (una vez como
        texto corrido, otra vez como tabla marcada). Eliminar esa
        duplicación es trabajo de normalización, y le corresponde al
        módulo Extractor de texto, no a este.
        """
        tables = page.extract_tables()
        if not tables:
            return ""

        rendered_tables = []
        for table_index, table in enumerate(tables, start=1):
            rows_text = [f"[Tabla {table_index}]"]
            for row in table:
                cells = [(cell or "").strip() for cell in row]
                rows_text.append(" | ".join(cells))
            rendered_tables.append("\n".join(rows_text))

        return "\n".join(rendered_tables)
