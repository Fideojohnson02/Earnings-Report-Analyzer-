"""
Loader de archivos de texto plano (.txt).

Responsabilidad única: leer un archivo .txt tal cual está. No
interpreta el contenido de ninguna forma.
"""

from __future__ import annotations

from src.loaders.base_loader import FileLoader, LoaderError


class TXTLoader(FileLoader):
    """
    Lee un archivo .txt.

    Intenta primero con codificación UTF-8 (la más común hoy en día).
    Si el archivo viene de un sistema viejo o de otro idioma con
    "acentos raros" al abrirlo, reintenta con Latin-1, que acepta
    cualquier secuencia de bytes sin fallar.
    """

    def _extract_text(self) -> str:
        try:
            return self.file_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            try:
                return self.file_path.read_text(encoding="latin-1")
            except Exception as exc:
                raise LoaderError(
                    f"No se pudo leer el TXT '{self.file_path.name}' "
                    f"ni en UTF-8 ni en Latin-1: {exc}"
                ) from exc
        except Exception as exc:
            raise LoaderError(
                f"No se pudo leer el TXT '{self.file_path.name}': {exc}"
            ) from exc
