"""Document Analyzer.

Segmenta el documento, conserva metadata estructural y linealiza
headings. La búsqueda de términos y la creación de candidatos son
responsabilidad exclusiva del Financial Candidate Finder.
"""
