"""Estructuras de datos del Document Analyzer.

El Document Analyzer conserva la estructura del documento y convierte
los headings en contexto textual. No busca términos financieros ni
crea candidatos: esa responsabilidad pertenece exclusivamente al
Financial Candidate Finder.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional


@dataclass(frozen=True)
class Paragraph:
    """Unidad estructural del documento.

    Si el párrafo pertenece a un heading, `text` ya está linealizado
    como ``Heading: [contenido]``. `heading` se conserva además como
    metadata de trazabilidad.
    """

    index: int
    section_number: Optional[int]
    heading: Optional[str]
    text: str
    is_table: bool


@dataclass(frozen=True)
class DocumentAnalysisResult:
    """Salida estructural del Document Analyzer.

    El resultado no contiene candidatos financieros. El siguiente
    módulo recibe `paragraphs` y realiza exclusivamente la búsqueda del
    vocabulario financiero.
    """

    original_text: str
    paragraphs: List[Paragraph]
