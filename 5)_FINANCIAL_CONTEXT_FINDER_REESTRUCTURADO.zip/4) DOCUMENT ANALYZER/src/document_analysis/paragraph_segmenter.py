"""Segmentador estructural y linealizador de headings.

El Document Analyzer no busca términos financieros. Convierte el texto
normalizado en párrafos y, cuando existe un heading, lo incorpora al
texto de cada bloque que queda bajo ese heading:

    Revenue
    It was 10% higher, to 100B.

se convierte en:

    Revenue: [It was 10% higher, to 100B.]

Los separadores de sección siempre cierran el bloque anterior y no
heredan headings de otra sección.
"""

from __future__ import annotations

import re
from typing import List, Optional

from src.document_analysis.models import Paragraph

_SECTION_LINE = re.compile(r"^--- Sección (\d+) ---$")
_HEADING_PREFIX = "# "
_TABLE_MARKER_LINE = re.compile(r"^\[Tabla(?: \d+)?\]$")


def segment_into_paragraphs(clean_text: str) -> List[Paragraph]:
    lines = clean_text.split("\n")
    paragraphs: List[Paragraph] = []

    current_section: Optional[int] = None
    current_heading: Optional[str] = None
    current_lines: List[str] = []
    table_lines: List[str] = []
    in_table = False

    def flush_text() -> None:
        nonlocal current_lines
        text = "\n".join(current_lines).strip()
        if text:
            paragraphs.append(
                Paragraph(
                    index=len(paragraphs),
                    section_number=current_section,
                    heading=current_heading,
                    text=_linearize_heading(current_heading, text),
                    is_table=False,
                )
            )
        current_lines = []

    def flush_table() -> None:
        nonlocal table_lines, in_table
        text = "\n".join(table_lines).strip()
        if text:
            paragraphs.append(
                Paragraph(
                    index=len(paragraphs),
                    section_number=current_section,
                    heading=current_heading,
                    text=_linearize_heading(current_heading, text),
                    is_table=True,
                )
            )
        table_lines = []
        in_table = False

    for line in lines:
        stripped = line.strip()

        section_match = _SECTION_LINE.match(stripped)
        if section_match:
            flush_text()
            if in_table:
                flush_table()
            current_section = int(section_match.group(1))
            current_heading = None
            continue

        if stripped.startswith(_HEADING_PREFIX):
            flush_text()
            if in_table:
                flush_table()
            current_heading = stripped[len(_HEADING_PREFIX):].strip()
            continue

        if _TABLE_MARKER_LINE.match(stripped):
            flush_text()
            if in_table:
                flush_table()
            in_table = True
            table_lines.append(line)
            continue

        if in_table:
            if "|" in stripped:
                table_lines.append(line)
                continue
            flush_table()

        if stripped == "":
            flush_text()
            continue

        current_lines.append(line)

    flush_text()
    if in_table:
        flush_table()

    return paragraphs


def _linearize_heading(heading: Optional[str], text: str) -> str:
    """Incluye el heading dentro de la evidencia textual del bloque."""
    if not heading:
        return text
    return f"{heading}: [{text}]"