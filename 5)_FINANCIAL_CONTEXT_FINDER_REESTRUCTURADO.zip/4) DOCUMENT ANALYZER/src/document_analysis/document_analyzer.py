"""Orquestador del Document Analyzer.

Responsabilidad única: convertir el texto normalizado en párrafos
estructurales y entregar los headings como contexto lineal. La búsqueda
de términos financieros pertenece al Financial Candidate Finder.
"""

from __future__ import annotations

from src.document_analysis.models import DocumentAnalysisResult
from src.document_analysis.paragraph_segmenter import segment_into_paragraphs
from src.logging_setup.logger import get_logger


class DocumentAnalyzer:
    """
    Recibe el texto uniforme del Extractor y devuelve un
    `DocumentAnalysisResult` con el documento original completo y los
    párrafos estructuralmente segmentados.
    """

    def __init__(self) -> None:
        self._logger = get_logger(__name__)

    def analyze(self, clean_text: str) -> DocumentAnalysisResult:
        paragraphs = segment_into_paragraphs(clean_text)
        self._log_summary(paragraphs)

        return DocumentAnalysisResult(
            original_text=clean_text, paragraphs=paragraphs
        )

    def _log_summary(self, paragraphs) -> None:
        self._logger.info(
            "Document Analyzer: %d párrafos estructurales generados.",
            len(paragraphs),
        )
