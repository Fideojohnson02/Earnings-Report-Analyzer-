"""Paquete de configuración de logging del sistema."""
