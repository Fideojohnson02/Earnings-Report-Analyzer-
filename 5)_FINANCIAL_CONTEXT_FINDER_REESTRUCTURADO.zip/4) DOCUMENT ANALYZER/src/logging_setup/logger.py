"""
Módulo de logging central del proyecto.

Responsabilidad única: configurar el sistema de logs de Python una sola
vez, al arrancar la aplicación, para que todos los demás módulos puedan
simplemente pedir su propio logger con `get_logger(__name__)` y usarlo,
sin preocuparse por cómo ni dónde se guardan los mensajes.

"Logging" es, en criollo, un registro de lo que va pasando en el
programa mientras corre (qué se procesó, qué falló, con qué datos).
Sirve para poder investigar un error después de que ocurrió, sin tener
que reproducirlo en el momento.
"""

from __future__ import annotations

import logging
import sys
from logging.handlers import RotatingFileHandler

from src.config.settings import Settings

# Formato de cada línea de log: fecha y hora | nivel | módulo | mensaje.
_LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

# Bandera interna para no configurar los handlers más de una vez.
_configured = False


def setup_logging(settings: Settings) -> None:
    """
    Configura el logger raíz de Python según la configuración del
    sistema.

    Agrega dos salidas ("handlers") a todos los logs de la aplicación:

      - Consola: para ver los mensajes mientras el programa corre.
      - Archivo rotativo: guarda un historial en disco. "Rotativo"
        significa que, cuando el archivo supera 5 MB, se renombra y se
        empieza uno nuevo, conservando como máximo 3 archivos viejos —
        así el log nunca crece sin límite.

    Es seguro llamar a esta función más de una vez (por ejemplo, si
    varios módulos la invocan): solo configura los handlers la primera
    vez, gracias a la bandera `_configured`.
    """
    global _configured
    if _configured:
        return

    settings.log_dir.mkdir(parents=True, exist_ok=True)
    log_file_path = settings.log_dir / "ai_earnings_analyzer.log"

    root_logger = logging.getLogger()
    root_logger.setLevel(settings.log_level)

    formatter = logging.Formatter(fmt=_LOG_FORMAT, datefmt=_DATE_FORMAT)

    console_handler = logging.StreamHandler(stream=sys.stdout)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    file_handler = RotatingFileHandler(
        filename=log_file_path,
        maxBytes=5 * 1024 * 1024,
        backupCount=3,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    root_logger.addHandler(file_handler)

    _configured = True


def get_logger(name: str) -> logging.Logger:
    """
    Devuelve un logger identificado con `name`.

    Convención: cada módulo debe llamar a `get_logger(__name__)`, para
    que en cada línea del log quede registrado de qué archivo vino ese
    mensaje (por ejemplo, `src.loaders.pdf_loader`).
    """
    return logging.getLogger(name)


def _reset_for_tests() -> None:
    """
    Reinicia el estado interno del módulo (la bandera `_configured` y
    los handlers ya agregados).

    Uso exclusivo de los tests automáticos: como `setup_logging` solo
    configura una vez por ejecución, sin esta función los tests que
    corren después del primero no podrían probar `setup_logging` de
    nuevo.
    """
    global _configured
    _configured = False
    root_logger = logging.getLogger()
    for handler in list(root_logger.handlers):
        handler.close()
        root_logger.removeHandler(handler)
