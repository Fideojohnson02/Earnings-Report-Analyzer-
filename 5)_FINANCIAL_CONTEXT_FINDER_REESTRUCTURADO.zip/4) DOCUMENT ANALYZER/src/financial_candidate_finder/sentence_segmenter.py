"""Segmentador heurístico de evidencia para el Financial Candidate Finder.

Reglas deliberadamente conservadoras:

* si después de un punto aparece un número, no se corta la evidencia;
* una nueva línea siempre inicia una evidencia nueva, aunque empiece con
  minúscula, un número, un punto, un asterisco o una enumeración;
* dentro de una misma línea solo se corta cuando la puntuación está
  seguida por una mayúscula o una comilla de apertura;
* las abreviaturas comunes y los decimales no generan cortes internos.

Si dos términos aparecen en la misma evidencia, el FCF crea dos
candidatos y luego agrupa esa evidencia para enviarla una sola vez al
único LLM.
"""

from __future__ import annotations

import re
from typing import List

_ABBREVIATIONS = [
    "Inc.", "Corp.", "Ltd.", "Co.", "L.P.", "L.L.C.", "LLC.",
    "vs.", "etc.", "e.g.", "i.e.", "approx.",
    "U.S.", "U.K.", "U.S.A.",
    "Mr.", "Mrs.", "Ms.", "Dr.", "Jr.", "Sr.", "St.",
    "No.", "Fig.",
]

_SORTED_ABBREVIATIONS = sorted(_ABBREVIATIONS, key=len, reverse=True)
_DECIMAL_PATTERN = re.compile(r"(\d)\.(\d)")
_PLACEHOLDER = "\x00"

# No incluye números deliberadamente: una puntuación seguida por un
# número no termina la evidencia según la regla del proyecto.
_SAME_LINE_BOUNDARY = re.compile(r"(?<=[.!?])\s+(?=[A-Z\"'¿¡])")


def split_into_sentences(paragraph_text: str) -> List[str]:
    """Divide texto corrido en evidencias completas y conservadoras."""
    if not paragraph_text or not paragraph_text.strip():
        return []

    text = paragraph_text.replace("\r\n", "\n").replace("\r", "\n")
    sentences: List[str] = []

    # La línea es una frontera explícita, incluso si la siguiente
    # empieza con minúscula o con un marcador de lista.
    for line in text.split("\n"):
        line = line.strip()
        if not line:
            continue
        protected = _protect_non_sentence_periods(line)
        pieces = _SAME_LINE_BOUNDARY.split(protected)
        sentences.extend(
            restored.strip()
            for restored in (_restore_periods(piece) for piece in pieces)
            if restored.strip()
        )

    return sentences


def _protect_non_sentence_periods(text: str) -> str:
    text = _DECIMAL_PATTERN.sub(rf"\1{_PLACEHOLDER}\2", text)

    for abbreviation in _SORTED_ABBREVIATIONS:
        def replace(match: re.Match[str]) -> str:
            return match.group(0).replace(".", _PLACEHOLDER)

        text = re.sub(
            re.escape(abbreviation),
            replace,
            text,
            flags=re.IGNORECASE,
        )

    return text


def _restore_periods(text: str) -> str:
    return text.replace(_PLACEHOLDER, ".")