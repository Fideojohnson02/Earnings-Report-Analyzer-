"""
Carga del vocabulario financiero amplio del Financial Candidate Finder.

El FCF utiliza DIRECTAMENTE `Financial_Terms_Synonyms.txt` como su
única fuente de búsqueda — este módulo solo lo parsea y lo expone como
un diccionario {categoría: [términos]}. No crea ninguna lista paralela
ni reducida, y no filtra ni reinterpreta ninguna categoría: cualquier
categoría o término que se agregue al archivo fuente queda disponible
para el FCF sin tocar este módulo.

Formato esperado del archivo (ver `Financial_Terms_Synonyms.txt`):

    ============================================================
    CATEGORÍA: REVENUE
    ============================================================
    revenue
    revenues
    ...

Cualquier línea que no sea un separador ("====...") ni un encabezado
de categoría ("CATEGORÍA: ...") se toma como un término de la
categoría vigente. Las líneas de título del archivo (antes de la
primera categoría) se ignoran.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, List, Optional

_CATEGORY_HEADER = re.compile(r"^CATEGOR[IÍ]A:\s*(.+)$", re.IGNORECASE)
_SEPARATOR_LINE = re.compile(r"^=+$")


class VocabularyLoadError(Exception):
    """
    Se lanza cuando `Financial_Terms_Synonyms.txt` no puede leerse o
    no contiene ninguna categoría reconocible.
    """


def load_financial_terms_vocabulary(path: Optional[Path] = None) -> Dict[str, List[str]]:
    """
    Lee y parsea el vocabulario financiero amplio.

    Si no se pasa `path`, se usa `settings.financial_terms_path` (la
    ruta centralizada de configuración). Se acepta un `path` explícito
    para tests y para uso programático fuera del flujo normal de
    configuración.
    """
    file_path = path if path is not None else _default_path()

    try:
        raw_text = file_path.read_text(encoding="utf-8")
    except OSError as exc:
        raise VocabularyLoadError(
            f"No se pudo leer el vocabulario financiero en '{file_path}': {exc}"
        ) from exc

    vocabulary = _parse_vocabulary(raw_text)

    if not vocabulary:
        raise VocabularyLoadError(
            f"El vocabulario financiero en '{file_path}' no contiene "
            "ninguna categoría reconocible (se esperaba al menos una "
            "línea 'CATEGORÍA: ...')."
        )

    return vocabulary


def _default_path() -> Path:
    # Import local (no al tope del módulo) para no crear una
    # dependencia circular en tiempo de import entre `config` y este
    # paquete si en el futuro `settings` necesitara algo de acá.
    from src.config.settings import get_settings

    return get_settings().financial_terms_path


def _parse_vocabulary(raw_text: str) -> Dict[str, List[str]]:
    vocabulary: Dict[str, List[str]] = {}
    current_category: Optional[str] = None

    for line in raw_text.split("\n"):
        stripped = line.strip()

        if not stripped or _SEPARATOR_LINE.match(stripped):
            continue

        header_match = _CATEGORY_HEADER.match(stripped)
        if header_match:
            current_category = header_match.group(1).strip()
            vocabulary.setdefault(current_category, [])
            continue

        if current_category is not None:
            vocabulary[current_category].append(stripped)

    # Se descartan categorías que quedaron sin ningún término (por
    # ejemplo, un encabezado sin contenido debajo) para no generar
    # búsquedas vacías.
    return {category: terms for category, terms in vocabulary.items() if terms}
