"""
Financial Candidate Finder (FCF).

Etapa del pipeline ubicada inmediatamente después del Document
Analyzer y antes de la LLM Provider Layer / única ejecución del LLM.

Responsabilidad única: buscar, en el texto ya segmentado por el
Document Analyzer, las apariciones de los términos definidos en
`Financial_Terms_Synonyms.txt` (el vocabulario financiero amplio del
proyecto), conservar la oración completa (o el bloque de tabla
completo) donde aparecen, y entregar candidatos listos para que la
única ejecución del LLM los interprete.

El FCF no interpreta economía, no interpreta números, no resuelve
sinónimos de movimiento, no asigna signos financieros, no descarta
subtipos, no hace scoring y no llama a ningún LLM. Ver el documento
`PROMPT — FINANCIAL CANDIDATE FINDER` para el detalle completo de
estas limitaciones, que son parte deliberada del diseño.
"""

from src.financial_candidate_finder.candidate_finder import FinancialCandidateFinder
from src.financial_candidate_finder.models import (
    EvidenceGroup,
    FCFResult,
    FinancialCandidate,
)
from src.financial_candidate_finder.vocabulary import (
    VocabularyLoadError,
    load_financial_terms_vocabulary,
)

__all__ = [
    "FinancialCandidateFinder",
    "FinancialCandidate",
    "EvidenceGroup",
    "FCFResult",
    "VocabularyLoadError",
    "load_financial_terms_vocabulary",
]
