"""
Financial Candidate Finder (FCF) — orquestador.

Recibe el `DocumentAnalysisResult` que produce el Document Analyzer
(los párrafos ya segmentados, con su metadata de sección/encabezado y
la marca `is_table`) y busca, dentro de ese texto, las apariciones de
los términos definidos en `Financial_Terms_Synonyms.txt`.

Principio de diseño (ver PROMPT — FINANCIAL CANDIDATE FINDER):

    BUSCAR -> DETECTAR -> CONSERVAR CONTEXTO -> ENTREGAR CANDIDATOS.

El FCF NO interpreta economía, NO interpreta números, NO resuelve
sinónimos de movimiento ("rose", "grew", "declined", ...), NO asigna
signos financieros, NO decide si una aparición es la métrica general o
un subtipo, NO hace scoring y NO llama a ningún LLM. Todas esas
responsabilidades quedan, deliberadamente, para etapas posteriores.

Decisiones de diseño explícitas (documentadas acá para trazabilidad):

- Cada candidato conserva la ORACIÓN COMPLETA como contexto mínimo
  (o el bloque de tabla completo, si el párrafo de origen es una
  tabla) — nunca solo la palabra o un fragmento alrededor de ella.
- Una misma evidencia puede generar más de un candidato, incluso si el
  mismo término aparece dos veces en posiciones distintas. Esto es
  intencional: el FCF no deduplica semánticamente.
- Dentro de una misma categoría, si un término más largo ya cubrió un
  tramo de texto (por ejemplo "net revenue"), no se vuelve a generar
  un candidato separado para un término más corto contenido en ese
  mismo tramo (por ejemplo "revenue"). Esto no es una decisión sobre
  qué término es "correcto" -- es evitar que el propio mecanismo de
  búsqueda cuente dos veces la misma aparición física por tener dos
  entradas de vocabulario superpuestas en la misma categoría (ver
  sección 10 del prompt: "la única protección requerida es evitar
  duplicaciones accidentales causadas por el propio mecanismo de
  búsqueda"). Términos de categorías distintas nunca se suprimen entre
  sí, aunque sus tramos se superpongan.
- La deduplicación interna por (párrafo, categoría, término,
  evidencia, posición) solo evita que un bug inserte dos veces la misma
  coincidencia física. Las evidencias iguales se agrupan después en
  `EvidenceGroup` para no enviarlas repetidas al único LLM.
"""

from __future__ import annotations

import re
from typing import Dict, List, Optional, Pattern, Set, Tuple

from src.document_analysis.models import DocumentAnalysisResult
from src.financial_candidate_finder.models import (
    EvidenceGroup,
    FCFResult,
    FinancialCandidate,
)
from src.financial_candidate_finder.sentence_segmenter import split_into_sentences
from src.financial_candidate_finder.token_estimator import estimate_tokens_for_contexts
from src.financial_candidate_finder.vocabulary import load_financial_terms_vocabulary
from src.logging_setup.logger import get_logger

_DedupKey = Tuple[int, str, str, str, int]


class FinancialCandidateFinder:
    """
    Busca en un `DocumentAnalysisResult` las apariciones del
    vocabulario financiero amplio y devuelve un `FCFResult` con los
    candidatos detectados.
    """

    def __init__(self, vocabulary: Optional[Dict[str, List[str]]] = None) -> None:
        """
        `vocabulary` es opcional y existe principalmente para tests:
        en uso normal, el FCF carga `Financial_Terms_Synonyms.txt`
        directamente a través de `load_financial_terms_vocabulary()`.
        """
        raw_vocabulary = (
            vocabulary if vocabulary is not None else load_financial_terms_vocabulary()
        )
        self._compiled_terms = _compile_vocabulary(raw_vocabulary)
        self._logger = get_logger(__name__)

    def find_candidates(self, analysis_result: DocumentAnalysisResult) -> FCFResult:
        candidates: List[FinancialCandidate] = []
        seen: Set[_DedupKey] = set()
        next_id = 0

        for paragraph in analysis_result.paragraphs:
            context_units = (
                [paragraph.text]
                if paragraph.is_table
                else split_into_sentences(paragraph.text)
            )

            for unit in context_units:
                for category, term, matched_text, match_start in self._find_matches(unit):
                    dedup_key: _DedupKey = (
                        paragraph.index,
                        category,
                        term,
                        unit,
                        match_start,
                    )
                    if dedup_key in seen:
                        continue
                    seen.add(dedup_key)

                    candidates.append(
                        FinancialCandidate(
                            id=next_id,
                            matched_metric=category,
                            matched_term=term,
                            matched_text=matched_text,
                            evidence=unit,
                            paragraph_index=paragraph.index,
                            section_number=paragraph.section_number,
                            heading=paragraph.heading,
                            is_table=paragraph.is_table,
                        )
                    )
                    next_id += 1

        evidence_groups = _group_evidence(candidates)
        estimated_tokens = estimate_tokens_for_contexts(
            group.evidence for group in evidence_groups
        )

        result = FCFResult(
            candidates=candidates,
            candidates_found=len(candidates),
            evidence_groups=evidence_groups,
            estimated_input_tokens=estimated_tokens,
        )
        self._log_summary(result)
        return result

    def _find_matches(self, text: str) -> List[Tuple[str, str, str, int]]:
        """
        Devuelve una lista de (categoría, término, texto_literal,
        posición_inicial) para
        todas las coincidencias encontradas en `text`, sin repetir un
        mismo tramo de texto dentro de una misma categoría (ver
        docstring del módulo).
        """
        if not text:
            return []

        matches: List[Tuple[str, str, str, int]] = []

        for category, terms in self._compiled_terms.items():
            occupied_spans: List[Tuple[int, int]] = []

            for term, pattern in terms:
                for match in pattern.finditer(text):
                    span = match.span()
                    if _overlaps_any(span, occupied_spans):
                        continue
                    occupied_spans.append(span)
                    matches.append((category, term, match.group(0), match.start()))

        return matches

    def _log_summary(self, result: FCFResult) -> None:
        self._logger.info(
            "Financial Candidate Finder: %d candidatos detectados. "
            "Estimated input tokens: %d.",
            result.candidates_found,
            result.estimated_input_tokens,
        )


def _compile_vocabulary(
    vocabulary: Dict[str, List[str]]
) -> Dict[str, List[Tuple[str, "Pattern[str]"]]]:
    """
    Precompila un patrón de regex por término, agrupado por categoría.
    Dentro de cada categoría, los términos se ordenan de más largo a
    más corto: así, si "net revenue" y "revenue" están ambos en la
    lista, un texto que contiene "net revenue" se evalúa primero
    contra el término más largo (ver docstring del módulo).
    """
    compiled: Dict[str, List[Tuple[str, "Pattern[str]"]]] = {}
    for category, terms in vocabulary.items():
        sorted_terms = sorted(terms, key=len, reverse=True)
        compiled[category] = [(term, _build_term_pattern(term)) for term in sorted_terms]
    return compiled


def _group_evidence(
    candidates: List[FinancialCandidate],
) -> List[EvidenceGroup]:
    """Deduplica la evidencia sin fusionar candidatos distintos."""
    candidate_ids_by_evidence: Dict[str, List[int]] = {}
    for candidate in candidates:
        candidate_ids_by_evidence.setdefault(candidate.evidence, []).append(candidate.id)

    return [
        EvidenceGroup(evidence=evidence, candidate_ids=tuple(candidate_ids))
        for evidence, candidate_ids in candidate_ids_by_evidence.items()
    ]


def _build_term_pattern(term: str) -> "Pattern[str]":
    """
    Construye un patrón que matchea `term` como unidad completa (no
    como substring suelto dentro de otra palabra), sin depender de
    `\\b`, que se comporta mal con términos que terminan en caracteres
    no alfanuméricos (por ejemplo "gross margin %", "D/E", "LTV/CAC").
    En su lugar, se exige explícitamente que no haya un caracter
    alfanumérico inmediatamente antes ni después de la coincidencia.
    """
    escaped = re.escape(term)
    pattern = rf"(?<![A-Za-z0-9]){escaped}(?![A-Za-z0-9])"
    return re.compile(pattern, re.IGNORECASE)


def _overlaps_any(span: Tuple[int, int], occupied_spans: List[Tuple[int, int]]) -> bool:
    start, end = span
    return any(start < occ_end and end > occ_start for occ_start, occ_end in occupied_spans)
