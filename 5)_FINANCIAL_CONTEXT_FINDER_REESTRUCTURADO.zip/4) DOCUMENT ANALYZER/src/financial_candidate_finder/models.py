"""
Estructuras de datos del Financial Candidate Finder.

Un `FinancialCandidate` NO es un Financial Fact: es simplemente el
registro de que un término del vocabulario financiero apareció en un
punto del documento, junto con la oración (o bloque de tabla) completa
como contexto y la metadata técnica necesaria para trazabilidad
interna. La interpretación de qué significa esa aparición queda,
deliberadamente, fuera de este módulo.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple


@dataclass(frozen=True)
class FinancialCandidate:
    """
    Un candidato individual detectado por el FCF.

    Atributos:
        id: identificador secuencial del candidato dentro del
            resultado del FCF (no es un ID global del sistema).
        matched_metric: la categoría del vocabulario financiero que
            produjo la coincidencia, tal como aparece en
            `Financial_Terms_Synonyms.txt` (por ejemplo "REVENUE").
            El FCF nunca decide si la aparición corresponde
            exactamente a esa métrica o a un subtipo — eso queda para
            la única ejecución del LLM.
        matched_term: el término exacto del vocabulario (dentro de
            `matched_metric`) que produjo la coincidencia (por
            ejemplo "net sales").
        matched_text: el texto literal, tal cual aparece en el
            documento, que coincidió con `matched_term` (conserva
            mayúsculas/minúsculas originales).
        evidence: la oración completa donde apareció el término (o,
            si el candidato proviene de una tabla, el bloque de tabla
            completo). Es la evidencia que debe recibir la única
            ejecución del LLM.
        paragraph_index: índice del `Paragraph` (del Document
            Analyzer) del que proviene este candidato.
        section_number: metadata de trazabilidad heredada del
            `Paragraph` de origen.
        heading: metadata de trazabilidad heredada del `Paragraph` de
            origen.
        is_table: si el candidato proviene de un bloque de tabla en
            vez de texto corrido.
    """

    id: int
    matched_metric: str
    matched_term: str
    matched_text: str
    evidence: str
    paragraph_index: int
    section_number: Optional[int]
    heading: Optional[str]
    is_table: bool

    def to_trace_dict(self) -> Dict[str, object]:
        """
        Trazabilidad interna del candidato: de qué término/categoría
        salió, en qué párrafo y sección, y con qué contexto. No está
        pensado como un sistema de citas visible para el usuario final
        — es un mecanismo de doble chequeo interno.
        """
        return {
            "id": self.id,
            "matched_metric": self.matched_metric,
            "matched_term": self.matched_term,
            "matched_text": self.matched_text,
            "evidence": self.evidence,
            "paragraph_index": self.paragraph_index,
            "section": self.heading,
            "page": self.section_number,
            "is_table": self.is_table,
        }


@dataclass(frozen=True)
class EvidenceGroup:
    """Una evidencia única asociada a uno o más candidatos.

    El FCF mantiene candidatos individuales para no perder hechos
    distintos, pero agrupa la evidencia repetida para que el único LLM
    reciba una oración una sola vez.
    """

    evidence: str
    candidate_ids: Tuple[int, ...]


@dataclass(frozen=True)
class FCFResult:
    """
    Salida completa del Financial Candidate Finder.

    Atributos:
        candidates: la lista plana de candidatos detectados.
        candidates_found: cantidad de candidatos detectados (NO es
            cantidad de Financial Facts, ni de métricas válidas, ni de
            nada que implique interpretación posterior).
        evidence_groups: evidencias únicas con los IDs de candidatos
            que comparten cada una. Es la forma deduplicada de preparar
            la entrada del único LLM.
        estimated_input_tokens: estimación aproximada de tokens de
            entrada que ocuparía el texto deduplicado. Es puramente
            informativo: no implica ninguna llamada a un LLM ni a una
            API externa.
    """

    candidates: List[FinancialCandidate]
    candidates_found: int
    evidence_groups: List[EvidenceGroup]
    estimated_input_tokens: int
