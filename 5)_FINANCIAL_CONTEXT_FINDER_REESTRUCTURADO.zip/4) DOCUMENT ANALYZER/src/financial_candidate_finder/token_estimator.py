"""
Estimador de tokens de entrada.

Estima, de forma aproximada, cuántos tokens ocuparía en la única
ejecución del LLM el texto que el FCF dejó seleccionado como contexto
(candidatos + oraciones/tablas asociadas).

Es una heurística basada en longitud de caracteres, independiente de
cualquier tokenizer específico de un proveedor. NO implica ninguna
llamada a un LLM ni a una API externa — es puramente informativo, tal
como pide el diseño del FCF.
"""

from __future__ import annotations

from typing import Iterable

# Heurística estándar para texto en inglés: aproximadamente 4
# caracteres por token. No es exacta para ningún tokenizer en
# particular, pero alcanza para dar una idea de magnitud.
_CHARS_PER_TOKEN = 4.0


def estimate_tokens(text: str) -> int:
    """Estima la cantidad de tokens de un texto individual."""
    if not text:
        return 0
    return max(1, round(len(text) / _CHARS_PER_TOKEN))


def estimate_tokens_for_contexts(contexts: Iterable[str]) -> int:
    """
    Estima el total de tokens sobre un conjunto de contextos
    (oraciones u bloques de tabla).

    Los contextos se cuentan como ÚNICOS: si dos candidatos distintos
    comparten exactamente el mismo texto de contexto (por ejemplo,
    porque dos términos financieros distintos aparecieron en la misma
    oración), ese texto se cuenta una sola vez. Es el mismo texto que
    se enviaría una sola vez a la única ejecución del LLM -- no una
    vez por cada candidato que lo referencia.
    """
    unique_contexts = set(contexts)
    return sum(estimate_tokens(context) for context in unique_contexts)
