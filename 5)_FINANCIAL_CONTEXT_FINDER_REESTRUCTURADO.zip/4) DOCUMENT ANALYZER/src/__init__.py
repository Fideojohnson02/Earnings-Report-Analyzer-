"""
Paquete principal del proyecto AI Earnings Analyzer.

Este archivo está vacío a propósito: su única función es indicarle a
Python que la carpeta `src` es un "paquete" (un conjunto de módulos que
se pueden importar), no una carpeta cualquiera.
"""
