"""
Extractor de texto.

Responsabilidad única: recibir el texto plano que produjo CUALQUIER
Loader (PDF, DOCX, PPTX, TXT, texto pegado, o uno futuro como una URL
de Investor Relations) y devolver una versión limpia y uniforme de ese
texto, lista para que el Parser financiero trabaje sobre ella.

Este módulo no sabe nada del formato de origen del texto — por diseño.
Esa es justamente la frontera con los Loaders: ellos conocen el
formato, este módulo no. Tampoco interpreta información financiera:
no busca EPS, Revenue, Guidance ni ningún otro dato, y no aplica
ninguna regla de negocio. Eso es responsabilidad del Parser financiero.
"""

from __future__ import annotations

import re
import unicodedata

from src.logging_setup.logger import get_logger

# --- Constantes de configuración de la pipeline -----------------------

# Caracteres "problemáticos" que normalizamos a su equivalente simple,
# para que el resto del sistema no tenga que lidiar con variantes
# tipográficas del mismo símbolo.
_UNICODE_REPLACEMENTS = {
    "\u2018": "'",  # comilla simple izquierda curva
    "\u2019": "'",  # comilla simple derecha curva
    "\u201c": '"',  # comilla doble izquierda curva
    "\u201d": '"',  # comilla doble derecha curva
    "\u2013": "-",  # en dash
    "\u2014": "-",  # em dash
    "\u00a0": " ",  # espacio de no separación (non-breaking space)
    "\u200b": "",  # espacio de ancho cero
    "\u00ad": "",  # guion suave (soft hyphen), invisible salvo al cortar línea
}

# Los Loaders usan "--- Página N ---" (PDF) o "--- Slide N ---" (PPTX).
# Acá los unificamos en un solo formato, para que el resto del sistema
# no necesite saber de qué tipo de archivo vino cada sección.
_PAGE_OR_SLIDE_SEPARATOR = re.compile(r"^--- (?:Página|Slide) (\d+) ---$", re.MULTILINE)

_SECTION_SEPARATOR_LINE = re.compile(r"^--- Sección \d+ ---$")
_TABLE_MARKER_LINE = re.compile(r"^\[Tabla(?: \d+)?\]$")

_MAX_HEADING_LENGTH = 80
_SENTENCE_ENDING_PUNCTUATION = (".", ",", ";", ":")

# Mínimo de caracteres no blancos para considerar que hay contenido
# real. Un valor bajo a propósito: el objetivo es detectar casos
# claramente vacíos o rotos, no exigir un largo mínimo "razonable".
_MIN_VALID_LENGTH = 20


class TextExtractionError(Exception):
    """Se lanza cuando el texto de entrada o de salida es insuficiente."""


# --- Pasos de la pipeline, como funciones puras ------------------------
# Cada función recibe texto y devuelve texto. Ninguna tiene estado ni
# efectos secundarios, lo que las hace fáciles de testear por separado
# (ver tests/test_text_extractor.py).


def _normalize_unicode(text: str) -> str:
    """
    Normaliza el texto a una forma unicode estándar (NFKC, que
    convierte, por ejemplo, ligaduras como "fi" unida en un solo
    carácter a "f" + "i" por separado) y reemplaza los caracteres
    "problemáticos" definidos arriba por su equivalente simple.
    """
    text = unicodedata.normalize("NFKC", text)
    for old, new in _UNICODE_REPLACEMENTS.items():
        text = text.replace(old, new)
    return text


def _normalize_section_separators(text: str) -> str:
    """Unifica los separadores de página/slide en un solo formato."""
    return _PAGE_OR_SLIDE_SEPARATOR.sub(r"--- Sección \1 ---", text)


def _normalize_whitespace(text: str) -> str:
    """
    Normaliza espacios y saltos de línea:

      - Distintas convenciones de fin de línea (\\r\\n, \\r) se llevan
        todas a \\n.
      - Espacios y tabs repetidos dentro de una línea se colapsan a
        uno solo.
      - Espacios al principio/final de cada línea se eliminan.
      - Más de una línea en blanco seguida se colapsa a una sola (así
        se preserva la separación entre párrafos, sin dejar "huecos"
        de tamaño variable según el formato de origen).
    """
    text = text.replace("\r\n", "\n").replace("\r", "\n")

    lines = [re.sub(r"[ \t]+", " ", line).strip() for line in text.split("\n")]

    normalized_lines: list[str] = []
    blank_run = 0
    for line in lines:
        if line == "":
            blank_run += 1
            if blank_run <= 1:
                normalized_lines.append(line)
        else:
            blank_run = 0
            normalized_lines.append(line)

    return "\n".join(normalized_lines).strip("\n")


def _deduplicate_table_echo(text: str) -> str:
    """
    Corrige una duplicación conocida y documentada desde el módulo de
    Loaders: cuando un PDF tiene una tabla, `pdfplumber` extrae esa
    misma fila dos veces — una vez como texto corrido (sin marcar) y
    otra vez dentro de un bloque `[Tabla N]`. Acá eliminamos la copia
    sin marcar, siempre y cuando coincida EXACTAMENTE (ignorando
    espacios) con una fila que ya está preservada en la tabla, y solo
    buscando dentro de la sección actual (nunca en secciones
    distintas). No se borra nada que no sea una copia exacta y
    confirmada de una fila ya conservada.
    """
    lines = text.split("\n")
    output: list[str] = []
    section_start = 0  # índice en `output` donde arranca la sección actual

    index = 0
    while index < len(lines):
        line = lines[index]
        stripped = line.strip()

        if _SECTION_SEPARATOR_LINE.match(stripped):
            output.append(line)
            section_start = len(output)
            index += 1
            continue

        if _TABLE_MARKER_LINE.match(stripped):
            table_block = [line]
            flattened_rows: list[str] = []
            index += 1
            while index < len(lines) and "|" in lines[index]:
                table_block.append(lines[index])
                cells = [cell.strip() for cell in lines[index].split("|")]
                flattened_rows.append(" ".join(cell for cell in cells if cell))
                index += 1

            normalized_targets = {" ".join(row.split()) for row in flattened_rows}
            output[section_start:] = [
                existing
                for existing in output[section_start:]
                if " ".join(existing.split()) not in normalized_targets
            ]

            output.extend(table_block)
            continue

        output.append(line)
        index += 1

    return "\n".join(output)


def _detect_headings(text: str) -> str:
    """
    Marca con "# " las líneas que, por su forma, parecen un título o
    encabezado — solo para fuentes que no traen esa metadata nativa
    (principalmente PDF). Es una heurística puramente estructural, sin
    ninguna palabra clave específica de una empresa o un documento:

      - Todo en mayúsculas ("RISK FACTORS"), o
      - Cada palabra capitalizada ("Financial Highlights") Y aislada
        por una línea en blanco o un separador de sección antes o
        después.

    Además, la línea debe ser corta (hasta 80 caracteres) y no debe
    terminar en puntuación de cierre de oración (".", ",", ";", ":"),
    que es lo típico de una oración de texto corrido, no de un título.
    """
    lines = text.split("\n")
    result = []
    for index, line in enumerate(lines):
        if _looks_like_heading(line, lines, index):
            result.append(f"# {line.strip()}")
        else:
            result.append(line)
    return "\n".join(result)


def _looks_like_heading(line: str, lines: list[str], index: int) -> bool:
    stripped = line.strip()

    if not stripped or len(stripped) > _MAX_HEADING_LENGTH:
        return False
    if stripped.startswith(("#", "[Tabla", "---")) or "|" in stripped:
        return False
    if stripped[-1] in _SENTENCE_ENDING_PUNCTUATION:
        return False
    if not any(char.isalpha() for char in stripped):
        return False

    words = [word for word in stripped.split(" ") if word]
    if not words:
        return False

    is_all_caps = stripped.upper() == stripped
    is_title_case = len(words) <= 8 and all(
        word[0].isupper() for word in words if word[0].isalpha()
    )

    if is_all_caps:
        return True

    previous_line = lines[index - 1].strip() if index > 0 else ""
    next_line = lines[index + 1].strip() if index + 1 < len(lines) else ""
    is_isolated = (
        previous_line == ""
        or previous_line.startswith("---")
        or next_line == ""
    )

    return is_title_case and is_isolated


def _ensure_sufficient_content(text: str, stage: str) -> None:
    """
    Lanza `TextExtractionError` si, descontando los espacios en
    blanco, queda muy poco contenido real. Se llama dos veces: al
    principio (texto de entrada vacío o casi vacío) y al final
    (por si la limpieza, por algún error, terminara vaciando el
    texto — chequeo defensivo).
    """
    non_whitespace_length = len(re.sub(r"\s", "", text))
    if non_whitespace_length < _MIN_VALID_LENGTH:
        raise TextExtractionError(
            f"El texto {stage} tiene contenido insuficiente "
            f"({non_whitespace_length} caracteres útiles, mínimo "
            f"{_MIN_VALID_LENGTH}). Puede tratarse de un documento vacío, "
            "un PDF escaneado sin texto extraíble (el Extractor no hace "
            "OCR), o un archivo con muy poco contenido real."
        )


class TextExtractor:
    """
    Normaliza y limpia el texto producido por cualquier Loader, para
    entregar una representación uniforme a los módulos posteriores.

    No sabe de dónde vino el texto (PDF, DOCX, PPTX, TXT, texto
    pegado, o un loader futuro) — solo recibe un `str` y devuelve un
    `str`. Esa es la frontera con los Loaders: ellos conocen el
    formato de origen, este módulo no.
    """

    def __init__(self) -> None:
        self._logger = get_logger(__name__)

    def extract(self, raw_text: str) -> str:
        """
        Aplica la pipeline completa de limpieza y devuelve el texto
        normalizado. Lanza `TextExtractionError` si el texto de
        entrada (o el resultado final) tiene contenido insuficiente.
        """
        _ensure_sufficient_content(raw_text, "de entrada")
        original_length = len(raw_text)

        text = _normalize_unicode(raw_text)
        text = _normalize_section_separators(text)
        text = _normalize_whitespace(text)
        text = _deduplicate_table_echo(text)
        text = _detect_headings(text)

        _ensure_sufficient_content(text, "luego de la limpieza")

        heading_count = sum(1 for line in text.split("\n") if line.startswith("# "))
        table_count = sum(
            1 for line in text.split("\n") if line.strip().startswith("[Tabla")
        )
        self._logger.info(
            "Texto normalizado: %d -> %d caracteres "
            "(%d encabezados detectados, %d tablas preservadas).",
            original_length,
            len(text),
            heading_count,
            table_count,
        )

        return text
