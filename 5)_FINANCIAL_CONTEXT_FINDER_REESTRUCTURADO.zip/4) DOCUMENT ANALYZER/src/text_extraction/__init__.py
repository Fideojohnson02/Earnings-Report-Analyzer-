"""Paquete del Extractor de texto: normaliza texto de cualquier Loader."""
