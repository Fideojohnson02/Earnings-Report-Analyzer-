"""
Módulo de configuración central del proyecto.

Responsabilidad única: leer los parámetros de configuración (desde
variables de entorno y, opcionalmente, desde un archivo .env) y
exponerlos como un único objeto tipado y validado (`Settings`).

Ningún otro módulo del sistema debe leer variables de entorno
directamente (con `os.getenv`) — todos deben pedirle la configuración
a este módulo a través de `get_settings()`. Así, si mañana cambiamos
de dónde viene la configuración (por ejemplo, a un archivo YAML), solo
hay que tocar este archivo.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

# Niveles de log válidos según el módulo estándar `logging` de Python.
VALID_LOG_LEVELS = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}


class ConfigError(Exception):
    """Se lanza cuando la configuración del sistema es inválida."""


@dataclass(frozen=True)
class Settings:
    """
    Representa toda la configuración del sistema en un único objeto.

    Usar `@dataclass` nos ahorra escribir a mano el método que arma el
    objeto a partir de sus campos. `frozen=True` significa que, una vez
    creado un objeto `Settings`, ningún otro módulo puede modificar sus
    valores por accidente.

    Atributos:
        environment: nombre del entorno actual ("development",
            "production", "test", etc.). Por ahora es solo informativo.
        log_level: nivel mínimo de detalle que se registra en los logs
            (DEBUG, INFO, WARNING, ERROR o CRITICAL).
        log_dir: carpeta donde se van a guardar los archivos de log.
        data_input_dir: carpeta donde se esperan los reportes que el
            usuario cargue (PDF, PPTX, DOCX, TXT).
        data_output_dir: carpeta donde se van a guardar los informes
            generados por el sistema.
        anthropic_api_key: clave para usar el LLM. Todavía no se usa
            (eso llega en el módulo de análisis con IA), pero la
            centralizamos acá desde ahora.
        financial_terms_path: ruta al archivo `Financial_Terms_Synonyms.txt`
            que usa el Financial Candidate Finder como su única fuente
            de vocabulario de búsqueda. Se centraliza acá (en vez de
            hardcodearla dentro del FCF) siguiendo el mismo criterio
            que ya se usa para el resto de las rutas de este módulo.
    """

    environment: str
    log_level: str
    log_dir: Path
    data_input_dir: Path
    data_output_dir: Path
    anthropic_api_key: Optional[str]
    financial_terms_path: Path

    def __post_init__(self) -> None:
        """Se ejecuta automáticamente después de crear el objeto.

        La usamos para validar que los valores recibidos tengan sentido,
        en lugar de descubrir el error más adelante, en otro módulo.
        """
        if self.log_level not in VALID_LOG_LEVELS:
            raise ConfigError(
                f"LOG_LEVEL inválido: '{self.log_level}'. "
                f"Debe ser uno de {sorted(VALID_LOG_LEVELS)}."
            )


def _load_settings_from_env(env_file: Optional[Path] = None) -> Settings:
    """
    Lee las variables de entorno (y, si existe, un archivo .env) y
    construye un objeto `Settings`.

    Si una variable no está definida, se usa un valor por defecto
    razonable, para poder trabajar en modo desarrollo sin configurar
    nada de entrada.

    Esta función empieza con "_" (guion bajo) para indicar que es de
    uso interno del módulo: el resto del sistema no debería llamarla
    directamente, sino usar `get_settings()`.
    """
    if env_file is not None:
        load_dotenv(dotenv_path=env_file, override=False)
    else:
        # Busca un archivo ".env" en la carpeta actual (si existe).
        load_dotenv(override=False)

    return Settings(
        environment=os.getenv("ENVIRONMENT", "development"),
        log_level=os.getenv("LOG_LEVEL", "INFO").upper(),
        log_dir=Path(os.getenv("LOG_DIR", "logs")),
        data_input_dir=Path(os.getenv("DATA_INPUT_DIR", "data/inputs")),
        data_output_dir=Path(os.getenv("DATA_OUTPUT_DIR", "data/outputs")),
        anthropic_api_key=os.getenv("ANTHROPIC_API_KEY") or None,
        financial_terms_path=Path(
            os.getenv(
                "FINANCIAL_TERMS_PATH",
                "data/financial_terms/Financial_Terms_Synonyms.txt",
            )
        ),
    )


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """
    Devuelve la configuración del sistema.

    Es la función que el resto de los módulos del proyecto debe usar.
    Está decorada con `@lru_cache(maxsize=1)`, lo que significa que el
    resultado se calcula una sola vez por ejecución del programa: la
    primera vez que se llama, lee el .env y las variables de entorno;
    las siguientes veces, devuelve el mismo objeto ya calculado, sin
    volver a leer nada.
    """
    return _load_settings_from_env()
