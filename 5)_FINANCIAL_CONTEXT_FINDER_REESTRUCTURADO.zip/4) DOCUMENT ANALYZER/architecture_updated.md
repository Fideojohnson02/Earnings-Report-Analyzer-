# Arquitectura — AI Earnings Analyzer

Este documento describe la arquitectura vigente del proyecto. La
implementación utiliza un único LLM y mantiene separadas la estructura
documental, la búsqueda literal, la comprensión contextual y la
interpretación financiera.

## 1. Flujo general

```text
Earnings Report
    ↓
Loader
    ↓
Text Extractor
    ↓
Document Analyzer
    ↓
Financial Candidate Finder
    ↓
Única ejecución del LLM
    ↓
Financial Fact Candidates
    ↓
Financial Parser
    ↓
Consensus / etapas cuantitativas
    ↓
Combinación de señales
    ↓
Reports / Decision
```

La separación central es:

```text
1. ORGANIZAR EL DOCUMENTO
   → Document Analyzer

2. ENCONTRAR CANDIDATOS LITERALES
   → Financial Candidate Finder

3. COMPRENDER EL LENGUAJE Y EL CONTEXTO
   → Único LLM

4. INTERPRETAR ECONÓMICAMENTE
   → Financial Parser
```

No existe una segunda capa LLM separada. El único LLM realiza tanto la
extracción financiera contextual como el análisis cualitativo.

## 2. Módulos implementados

### 2.1 Config & Logging

`src/config` centraliza la configuración y las rutas. `src/logging_setup`
configura logging a consola y archivo rotativo.

Estos módulos no interpretan información financiera.

### 2.2 Loaders

`src/loaders` soporta:

- PDF;
- DOCX;
- PPTX;
- TXT;
- texto pegado.

Cada Loader conoce el formato de entrada y devuelve texto. No busca
términos, no interpreta números y no aplica reglas financieras.

Limitación conocida: no se realiza OCR.

### 2.3 Text Extractor

`src/text_extraction` transforma el texto de los Loaders en una
representación uniforme. Sus responsabilidades son:

- normalizar Unicode;
- normalizar espacios y saltos;
- unificar separadores de página y slide;
- conservar tablas;
- deduplicar ecos documentados de tablas;
- detectar headings cuando el formato no aporta metadata;
- validar que exista contenido suficiente.

El Extractor no busca vocabulario financiero.

### 2.4 Document Analyzer

`src/document_analysis` tiene responsabilidad estructural, no
semántica.

Produce:

```text
DocumentAnalysisResult
    original_text
    paragraphs[]
        index
        section_number
        heading
        text
        is_table
```

Un párrafo se delimita por:

- línea en blanco;
- heading;
- bloque de tabla;
- cambio de sección.

Los cambios de sección siempre cierran el bloque anterior. Además, el
heading se reinicia al comenzar una nueva sección para evitar que la
metadata se filtre a otro contexto.

### 2.5 Linealización de headings

El heading se conserva como metadata y también se incorpora al texto
que recibirá el Financial Candidate Finder.

Entrada:

```text
# Revenue
It was 10% higher, to 100B.
```

Salida estructural:

```text
heading = "Revenue"
text = "Revenue: [It was 10% higher, to 100B.]"
```

El heading se aplica a cada bloque que permanece bajo él hasta que
aparece otro heading o cambia la sección.

El Document Analyzer no:

- importa vocabularios financieros;
- busca coincidencias;
- crea candidatos;
- agrega contexto anterior o posterior para decidir relevancia;
- interpreta valores;
- hace scoring.

## 3. Financial Candidate Finder

`src/financial_candidate_finder` recibe los párrafos del Document
Analyzer y utiliza únicamente:

```text
data/financial_terms/Financial_Terms_Synonyms.txt
```

El vocabulario se carga sin crear una lista paralela en código.

### 3.1 Salida

Cada aparición produce un `FinancialCandidate` independiente:

```text
id
matched_metric
matched_term
matched_text
evidence
paragraph_index
section_number
heading
is_table
```

La forma conceptual de entrega es:

```text
Candidate #1
Matched_metric: REVENUE
Evidence: "Revenue was 10% higher, to 100B."
Matched_term: "revenue"
```

`evidence` es la oración completa o el bloque completo de tabla. El
FCF no reemplaza la evidencia por un fragmento.

### 3.2 Repeticiones y deduplicación

El FCF no fusiona apariciones reales. Si un término aparece dos veces
en una misma oración, se generan dos candidatos con distintas
posiciones físicas.

La deduplicación interna incluye la posición de la coincidencia para
no perder hechos independientes.

Después se crea una lista de `EvidenceGroup`:

```text
EvidenceGroup
    evidence
    candidate_ids
```

Esto permite entregar una oración una sola vez al único LLM y asociarle
todos los candidatos encontrados en ella.

### 3.3 Tablas

Los bloques de tabla no pasan por el splitter de oraciones. Se
conservan completos para que el LLM pueda interpretar encabezados,
filas, columnas, períodos y valores en conjunto.

### 3.4 Responsabilidades excluidas

El FCF no:

- interpreta economía;
- interpreta números;
- resuelve `respectively`;
- normaliza `rose` a `INCREASED`;
- decide si un subtipo debe descartarse;
- asigna signos;
- hace scoring;
- llama a un proveedor externo.

## 4. Segmentación heurística de evidencia

`sentence_segmenter.py` aplica estas reglas:

1. Una puntuación seguida por un número no termina la evidencia.
2. Un salto de línea siempre inicia una nueva evidencia.
3. La regla del salto de línea se aplica aunque el texto empiece con
   minúscula, número, punto, asterisco o enumeración.
4. Una puntuación seguida por minúscula en la misma línea no divide el
   texto.
5. Decimales y abreviaturas conocidas se protegen.

La segmentación es heurística y conserva el texto original. No realiza
interpretación lingüística.

## 5. Único LLM

Esta capa se implementará después del FCF. Recibirá `EvidenceGroup` y
los candidatos asociados.

Deberá crear Financial Fact Candidates con:

- término;
- valor actual;
- valor anterior;
- variación porcentual;
- variación numérica;
- dirección lingüística;
- temporalidad;
- modificadores;
- incertidumbre;
- evidencia interna.

También analizará contenido cualitativo. No hará scoring final ni
decidirá LONG, SHORT o NO OPERAR.

La capa de proveedores debe abstraer la selección de proveedor y
modelo, pero no mezclar credenciales con la lógica financiera.

## 6. Financial Parser

El Financial Parser recibe hechos ya contextualizados por el único
LLM. Su trabajo es determinista:

- interpretar económicamente la dirección;
- determinar el signo financiero;
- calcular consecuencias según reglas;
- preparar señales cuantitativas.

No debe volver a resolver problemas de segmentación o de comprensión
del lenguaje.

## 7. Etapas futuras

### Consensus Comparison

Comparará los resultados obtenidos con las expectativas o consenso.

### Score Engine

Combinará señales financieras y cualitativas en un score explicable.

### Reports / Decision

Presentará resultados y, posteriormente, la decisión LONG, SHORT o NO
OPERAR.

### Backtesting, GUI y Live

Permanecen fuera del alcance actual.

## 8. Integridad y trazabilidad

Si el documento no contiene un dato o una asociación no puede
resolverse con seguridad, el sistema debe conservarlo como no
disponible o incierto.

Cada candidato conserva evidencia textual y metadata suficiente para
verificación interna. La trazabilidad no implica exponer coordenadas o
ubicaciones físicas al usuario final.

## 9. Regla de evolución

Cada etapa debe cerrarse con:

1. implementación;
2. tests;
3. regresión;
4. documentación;
5. verificación;
6. ZIP actualizado del proyecto.

La README, este archivo, `roadmap_updated.md` y
`requirements_updated.txt` se actualizan junto con cada cambio
arquitectónico.