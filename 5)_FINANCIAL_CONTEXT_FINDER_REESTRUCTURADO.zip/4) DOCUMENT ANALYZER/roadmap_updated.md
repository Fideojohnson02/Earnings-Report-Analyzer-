# Roadmap — AI Earnings Analyzer

Este roadmap refleja la arquitectura vigente con un único LLM y un
Document Analyzer exclusivamente estructural.

## 1. Completado

### Módulo 1 — Config & Logging

Estado: COMPLETO / APROBADO

### Módulo 2 — Loaders

Estado: COMPLETO / APROBADO

Soporta PDF, DOCX, PPTX, TXT y texto plano.

### Módulo 3 — Text Extractor

Estado: COMPLETO / APROBADO

Normaliza y conserva el contenido textual y las tablas.

### Módulo 4 — Document Analyzer

Estado: COMPLETO / REESTRUCTURADO

Ahora:

- segmenta párrafos estructurales;
- cierra bloques al cambiar de sección;
- no hereda headings entre secciones;
- convierte headings en contexto lineal;
- no busca términos financieros;
- no crea candidatos.

### Módulo 5 — Financial Candidate Finder

Estado: COMPLETO / ACTUALIZADO

Ahora:

- usa `Financial_Terms_Synonyms.txt` como vocabulario único;
- entrega `Matched_metric`, `Evidence` y `Matched_term`;
- conserva candidatos independientes para apariciones repetidas;
- agrupa evidencias iguales en `EvidenceGroup`;
- calcula tokens sobre evidencia deduplicada;
- no interpreta ni llama a un LLM.

## 2. Próximo componente

### Único LLM — Contextual Financial Extraction y análisis cualitativo

Estado: PRÓXIMO

Recibirá evidencias agrupadas y candidatos asociados.

Debe:

- comprender el contexto;
- resolver asociaciones entre términos y valores;
- interpretar sinónimos lingüísticos;
- producir Financial Fact Candidates;
- conservar incertidumbre;
- analizar información cualitativa.

No debe:

- hacer scoring final;
- decidir LONG, SHORT o NO OPERAR;
- inventar información;
- reemplazar las reglas del Financial Parser.

## 3. Financial Fact Candidates

Estado: PARTE DEL PRÓXIMO COMPONENTE

Salida estructurada del único LLM:

```text
term
current_value
previous_value
percentage_variation
numerical_variation
direction
temporal_context
modifiers
uncertainty
internal_evidence
```

## 4. Financial Parser

Estado: POSTERIOR AL ÚNICO LLM

Interpretará financieramente los hechos mediante reglas deterministas:

- signo financiero;
- consecuencia económica;
- señales cuantitativas;
- reglas de interpretación por métrica.

## 5. Consensus Comparison

Estado: FUTURO

Comparará los resultados del documento con consenso, expectativas y
surprises.

## 6. Score Engine

Estado: FUTURO

Combinará las señales financieras y cualitativas en un score
explicable.

## 7. Reports / Decision

Estado: FUTURO

Presentará:

- análisis fundamentado;
- score;
- evidencia;
- decisión LONG, SHORT o NO OPERAR.

## 8. Backtesting

Estado: FUTURO

Procesará reportes históricos con el mismo pipeline y comparará las
señales con el comportamiento posterior.

## 9. Desktop GUI

Estado: FUTURO

Aplicación de escritorio para Windows con:

- selección de archivos;
- drag & drop;
- historial;
- presentación de resultados;
- exportación.

## 10. Live / automatización

Estado: FUTURO / POSTERIOR

La descarga automática, detección de nuevos reportes y procesamiento
live quedan para una etapa posterior.

## 11. Regla de evolución

Cada componente debe cerrarse con:

1. implementación;
2. tests;
3. regresión;
4. documentación;
5. verificación;
6. ZIP actualizado.

README, `architecture_updated.md`, este roadmap y
`requirements_updated.txt` deben mantenerse sincronizados.