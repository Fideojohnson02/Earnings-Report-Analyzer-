"""
Pruebas unitarias del módulo `src/loaders`.

Cada test genera sus propios archivos de prueba en una carpeta
temporal (no depende de `scripts/generate_sample_files.py` ni de
`data/inputs/`), para que la suite de tests sea independiente y
repetible en cualquier máquina.

Cómo correr solo este archivo:

    python -m unittest tests.test_loaders -v
"""

import shutil
import tempfile
import unittest
from pathlib import Path

from docx import Document
from pptx import Presentation
from pptx.util import Inches
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

from src.loaders.base_loader import LoaderError
from src.loaders.docx_loader import DOCXLoader
from src.loaders.loader_factory import get_loader_for_file, get_loader_for_pasted_text
from src.loaders.pdf_loader import PDFLoader
from src.loaders.pptx_loader import PPTXLoader
from src.loaders.raw_text_loader import RawTextLoader
from src.loaders.txt_loader import TXTLoader


class LoaderTestCase(unittest.TestCase):
    """
    Clase base con una carpeta temporal común a todos los tests de
    loaders. `tempfile.mkdtemp()` crea una carpeta nueva en cada test
    y `tearDown` la borra al final, para no dejar basura en el disco.
    """

    def setUp(self) -> None:
        self.tmp_dir = Path(tempfile.mkdtemp(prefix="loader_tests_"))

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp_dir, ignore_errors=True)


class TestTXTLoader(LoaderTestCase):
    def test_reads_utf8_file(self) -> None:
        path = self.tmp_dir / "reporte.txt"
        path.write_text("Revenue: $100M\nEPS: $1.20", encoding="utf-8")

        text = TXTLoader(path).load()

        self.assertIn("Revenue: $100M", text)
        self.assertIn("EPS: $1.20", text)

    def test_falls_back_to_latin1(self) -> None:
        path = self.tmp_dir / "reporte_latin1.txt"
        # "é" codificado en Latin-1 no es una secuencia UTF-8 válida,
        # así que fuerza el fallback dentro de TXTLoader.
        path.write_bytes("Beneficio: 10% más que el año anterior".encode("latin-1"))

        text = TXTLoader(path).load()

        self.assertIn("Beneficio", text)

    def test_missing_file_raises_loader_error(self) -> None:
        missing_path = self.tmp_dir / "no_existe.txt"

        with self.assertRaises(LoaderError):
            TXTLoader(missing_path).load()

    def test_empty_file_raises_loader_error(self) -> None:
        path = self.tmp_dir / "vacio.txt"
        path.write_text("   \n  ", encoding="utf-8")

        with self.assertRaises(LoaderError):
            TXTLoader(path).load()


class TestRawTextLoader(unittest.TestCase):
    def test_returns_stripped_text(self) -> None:
        text = RawTextLoader("  Revenue: $100M  \n").load()
        self.assertEqual(text, "Revenue: $100M")

    def test_empty_text_raises_loader_error(self) -> None:
        with self.assertRaises(LoaderError):
            RawTextLoader("   ").load()


class TestPDFLoader(LoaderTestCase):
    def _build_sample_pdf(self) -> Path:
        path = self.tmp_dir / "reporte.pdf"
        pdf_canvas = canvas.Canvas(str(path), pagesize=letter)
        _, page_height = letter

        text_object = pdf_canvas.beginText(40, page_height - 50)
        text_object.setFont("Helvetica", 11)
        for line in ["Acme Corp Q2 2026", "Revenue: $482 million", "EPS: $1.35"]:
            text_object.textLine(line)
        pdf_canvas.drawText(text_object)

        pdf_canvas.showPage()
        text_object2 = pdf_canvas.beginText(40, page_height - 50)
        text_object2.setFont("Helvetica", 11)
        text_object2.textLine("Segunda página: riesgos y outlook.")
        pdf_canvas.drawText(text_object2)

        pdf_canvas.save()
        return path

    def test_preserves_page_order_and_content(self) -> None:
        path = self._build_sample_pdf()

        text = PDFLoader(path).load()

        self.assertIn("--- Página 1 ---", text)
        self.assertIn("--- Página 2 ---", text)
        self.assertIn("Revenue: $482 million", text)
        self.assertLess(
            text.index("--- Página 1 ---"), text.index("--- Página 2 ---")
        )
        self.assertLess(
            text.index("Revenue: $482 million"), text.index("--- Página 2 ---")
        )

    def test_missing_file_raises_loader_error(self) -> None:
        with self.assertRaises(LoaderError):
            PDFLoader(self.tmp_dir / "no_existe.pdf").load()

    def test_corrupted_pdf_raises_loader_error(self) -> None:
        path = self.tmp_dir / "corrupto.pdf"
        path.write_bytes(b"esto no es un PDF valido")

        with self.assertRaises(LoaderError):
            PDFLoader(path).load()


class TestDOCXLoader(LoaderTestCase):
    def _build_sample_docx(self) -> Path:
        path = self.tmp_dir / "reporte.docx"
        document = Document()
        document.add_heading("Resultados Q2 2026", level=1)
        document.add_paragraph("Revenue: $482 million")

        document.add_heading("Tabla de métricas", level=2)
        table = document.add_table(rows=2, cols=2)
        table.rows[0].cells[0].text = "Metric"
        table.rows[0].cells[1].text = "Value"
        table.rows[1].cells[0].text = "EPS"
        table.rows[1].cells[1].text = "$1.35"

        document.add_paragraph("Comentario final del CEO.")
        document.save(str(path))
        return path

    def test_marks_native_headings(self) -> None:
        path = self._build_sample_docx()

        text = DOCXLoader(path).load()

        self.assertIn("# Resultados Q2 2026", text)
        self.assertIn("# Tabla de métricas", text)

    def test_preserves_document_order_with_interleaved_table(self) -> None:
        path = self._build_sample_docx()

        text = DOCXLoader(path).load()

        # El orden real del documento es: encabezado -> párrafo ->
        # encabezado -> tabla -> párrafo. Si la tabla se procesara por
        # separado (como hace `document.tables`), terminaría siempre
        # al final, rompiendo este orden.
        idx_heading2 = text.index("# Tabla de métricas")
        idx_table = text.index("[Tabla 1]")
        idx_final_comment = text.index("Comentario final del CEO.")

        self.assertLess(idx_heading2, idx_table)
        self.assertLess(idx_table, idx_final_comment)

    def test_table_cells_are_pipe_separated(self) -> None:
        path = self._build_sample_docx()

        text = DOCXLoader(path).load()

        self.assertIn("EPS | $1.35", text)


class TestPPTXLoader(LoaderTestCase):
    def _build_sample_pptx(self) -> Path:
        path = self.tmp_dir / "reporte.pptx"
        presentation = Presentation()
        layout = presentation.slide_layouts[1]

        slide1 = presentation.slides.add_slide(layout)
        slide1.shapes.title.text = "Highlights Q2 2026"
        slide1.placeholders[1].text_frame.text = "Revenue: $482 million"

        slide2 = presentation.slides.add_slide(layout)
        slide2.shapes.title.text = "Guidance"
        table_shape = slide2.shapes.add_table(
            2, 2, Inches(1), Inches(3), Inches(4), Inches(1)
        )
        table_shape.table.cell(0, 0).text = "Metric"
        table_shape.table.cell(0, 1).text = "Value"
        table_shape.table.cell(1, 0).text = "EPS"
        table_shape.table.cell(1, 1).text = "$1.35"

        presentation.save(str(path))
        return path

    def test_marks_native_slide_titles_and_order(self) -> None:
        path = self._build_sample_pptx()

        text = PPTXLoader(path).load()

        self.assertIn("--- Slide 1 ---", text)
        self.assertIn("# Highlights Q2 2026", text)
        self.assertIn("--- Slide 2 ---", text)
        self.assertIn("# Guidance", text)
        self.assertLess(text.index("Slide 1"), text.index("Slide 2"))

    def test_does_not_duplicate_title_as_body_text(self) -> None:
        path = self._build_sample_pptx()

        text = PPTXLoader(path).load()

        # "Highlights Q2 2026" debe aparecer una sola vez (como
        # encabezado), no de nuevo suelto como texto de cuerpo.
        self.assertEqual(text.count("Highlights Q2 2026"), 1)

    def test_extracts_table_from_slide(self) -> None:
        path = self._build_sample_pptx()

        text = PPTXLoader(path).load()

        self.assertIn("EPS | $1.35", text)


class TestLoaderFactory(LoaderTestCase):
    def test_returns_correct_loader_by_extension(self) -> None:
        cases = [
            ("reporte.pdf", PDFLoader),
            ("reporte.PDF", PDFLoader),  # sin distinguir mayúsculas
            ("reporte.docx", DOCXLoader),
            ("reporte.pptx", PPTXLoader),
            ("reporte.txt", TXTLoader),
        ]
        for filename, expected_cls in cases:
            with self.subTest(filename=filename):
                loader = get_loader_for_file(self.tmp_dir / filename)
                self.assertIsInstance(loader, expected_cls)

    def test_unsupported_extension_raises_loader_error(self) -> None:
        with self.assertRaises(LoaderError):
            get_loader_for_file(self.tmp_dir / "reporte.rtf")

    def test_pasted_text_returns_raw_text_loader(self) -> None:
        loader = get_loader_for_pasted_text("Revenue: $100M")
        self.assertIsInstance(loader, RawTextLoader)
        self.assertEqual(loader.load(), "Revenue: $100M")


if __name__ == "__main__":
    unittest.main()
