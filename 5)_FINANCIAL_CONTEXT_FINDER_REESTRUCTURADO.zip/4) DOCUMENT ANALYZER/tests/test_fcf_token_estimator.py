"""
Pruebas del estimador de tokens (`token_estimator.py`).

Cómo correr solo este archivo:

    python -m unittest tests.test_fcf_token_estimator -v
"""

import unittest

from src.financial_candidate_finder.token_estimator import (
    estimate_tokens,
    estimate_tokens_for_contexts,
)


class TestEstimateTokens(unittest.TestCase):
    def test_empty_text_is_zero_tokens(self) -> None:
        self.assertEqual(estimate_tokens(""), 0)

    def test_short_text_is_at_least_one_token(self) -> None:
        self.assertGreaterEqual(estimate_tokens("Hi"), 1)

    def test_longer_text_scales_with_length(self) -> None:
        short_text = "Revenue grew."
        long_text = short_text * 10

        self.assertGreater(estimate_tokens(long_text), estimate_tokens(short_text))


class TestEstimateTokensForContexts(unittest.TestCase):
    def test_empty_iterable_is_zero(self) -> None:
        self.assertEqual(estimate_tokens_for_contexts([]), 0)

    def test_sums_distinct_contexts(self) -> None:
        contexts = ["Revenue grew 10%.", "Net income declined 5%."]
        total = estimate_tokens_for_contexts(contexts)
        expected = estimate_tokens(contexts[0]) + estimate_tokens(contexts[1])

        self.assertEqual(total, expected)

    def test_duplicate_contexts_counted_once(self) -> None:
        sentence = "Revenue and net loss both moved this quarter."
        total_with_duplicate = estimate_tokens_for_contexts([sentence, sentence])
        total_single = estimate_tokens_for_contexts([sentence])

        self.assertEqual(total_with_duplicate, total_single)


if __name__ == "__main__":
    unittest.main()
