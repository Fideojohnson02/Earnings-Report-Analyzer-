"""
Pruebas del módulo `src/text_extraction`.

Incluye tests unitarios de cada paso de la pipeline (por separado) y
tests de integración reales: Loader -> Extractor, para cada uno de los
4 formatos de archivo, confirmando que el Extractor funciona igual sin
importar el origen del texto.

Cómo correr solo este archivo:

    python -m unittest tests.test_text_extractor -v
"""

import shutil
import tempfile
import unittest
from pathlib import Path

from docx import Document
from pptx import Presentation
from pptx.util import Inches
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

from src.loaders.docx_loader import DOCXLoader
from src.loaders.pdf_loader import PDFLoader
from src.loaders.pptx_loader import PPTXLoader
from src.loaders.raw_text_loader import RawTextLoader
from src.loaders.txt_loader import TXTLoader
from src.text_extraction.text_extractor import (
    TextExtractionError,
    TextExtractor,
    _deduplicate_table_echo,
    _detect_headings,
    _normalize_section_separators,
    _normalize_unicode,
    _normalize_whitespace,
)


class TestNormalizeUnicode(unittest.TestCase):
    def test_replaces_curly_quotes(self) -> None:
        text = _normalize_unicode("\u201cGuidance\u201d and \u2018outlook\u2019")
        self.assertEqual(text, '"Guidance" and \'outlook\'')

    def test_replaces_dashes_with_hyphen(self) -> None:
        text = _normalize_unicode("Q2 2026 \u2014 Earnings")
        self.assertEqual(text, "Q2 2026 - Earnings")

    def test_replaces_non_breaking_space(self) -> None:
        text = _normalize_unicode("Revenue:\u00a0$100M")
        self.assertEqual(text, "Revenue: $100M")

    def test_removes_zero_width_space(self) -> None:
        text = _normalize_unicode("Rev\u200benue")
        self.assertEqual(text, "Revenue")


class TestNormalizeSectionSeparators(unittest.TestCase):
    def test_unifies_pdf_page_separator(self) -> None:
        text = _normalize_section_separators("--- Página 3 ---")
        self.assertEqual(text, "--- Sección 3 ---")

    def test_unifies_pptx_slide_separator(self) -> None:
        text = _normalize_section_separators("--- Slide 2 ---")
        self.assertEqual(text, "--- Sección 2 ---")


class TestNormalizeWhitespace(unittest.TestCase):
    def test_collapses_internal_spaces(self) -> None:
        text = _normalize_whitespace("Revenue:    $100M")
        self.assertEqual(text, "Revenue: $100M")

    def test_collapses_multiple_blank_lines(self) -> None:
        text = _normalize_whitespace("Line A\n\n\n\nLine B")
        self.assertEqual(text, "Line A\n\nLine B")

    def test_normalizes_windows_line_endings(self) -> None:
        text = _normalize_whitespace("Line A\r\nLine B\r\n")
        self.assertEqual(text, "Line A\nLine B")

    def test_strips_trailing_spaces_per_line(self) -> None:
        text = _normalize_whitespace("Line A   \nLine B")
        self.assertEqual(text, "Line A\nLine B")


class TestDeduplicateTableEcho(unittest.TestCase):
    def test_removes_exact_duplicate_row_before_table(self) -> None:
        text = (
            "--- Sección 1 ---\n"
            "Metric Value\n"
            "Gross margin 61.2%\n"
            "[Tabla 1]\n"
            "Metric | Value\n"
            "Gross margin | 61.2%"
        )

        result = _deduplicate_table_echo(text)

        self.assertNotIn("Metric Value\n", result)
        self.assertNotIn("Gross margin 61.2%\nGross margin", result)
        self.assertIn("[Tabla 1]", result)
        self.assertIn("Gross margin | 61.2%", result)

    def test_does_not_remove_unrelated_text(self) -> None:
        text = (
            "--- Sección 1 ---\n"
            "CEO comments: strong quarter overall.\n"
            "[Tabla 1]\n"
            "Metric | Value"
        )

        result = _deduplicate_table_echo(text)

        self.assertIn("CEO comments: strong quarter overall.", result)

    def test_does_not_remove_match_from_a_different_section(self) -> None:
        text = (
            "--- Sección 1 ---\n"
            "Net income 78\n"
            "--- Sección 2 ---\n"
            "[Tabla 1]\n"
            "Net income | 78"
        )

        result = _deduplicate_table_echo(text)

        # La coincidencia está en la Sección 1, la tabla en la Sección
        # 2: no deben tocarse entre sí.
        self.assertIn("Net income 78", result)


class TestDetectHeadings(unittest.TestCase):
    def test_marks_all_caps_line_as_heading(self) -> None:
        text = _detect_headings("RISK FACTORS\nSome body text follows.")
        self.assertTrue(text.startswith("# RISK FACTORS"))

    def test_marks_isolated_title_case_line_as_heading(self) -> None:
        text = _detect_headings(
            "--- Sección 1 ---\nFinancial Highlights\n\nRevenue grew this quarter."
        )
        self.assertIn("# Financial Highlights", text)

    def test_does_not_mark_regular_sentence(self) -> None:
        text = _detect_headings(
            "Revenue: $482 million, up 14% year-over-year."
        )
        self.assertFalse(text.startswith("#"))

    def test_does_not_double_mark_existing_heading(self) -> None:
        text = _detect_headings("# Already A Heading")
        self.assertEqual(text.count("#"), 1)

    def test_does_not_mark_table_rows(self) -> None:
        text = _detect_headings("[Tabla 1]\nMetric | Value")
        self.assertNotIn("# [Tabla", text)
        self.assertNotIn("# Metric", text)


class TestTextExtractorValidation(unittest.TestCase):
    def test_raises_on_empty_input(self) -> None:
        with self.assertRaises(TextExtractionError):
            TextExtractor().extract("   \n  ")

    def test_raises_on_too_short_input(self) -> None:
        with self.assertRaises(TextExtractionError):
            TextExtractor().extract("Q2")

    def test_valid_input_returns_cleaned_text(self) -> None:
        text = TextExtractor().extract(
            "Revenue:    $482 million, up 14% year-over-year."
        )
        self.assertIn("Revenue: $482 million", text)


class ExtractorIntegrationTestCase(unittest.TestCase):
    """Base con carpeta temporal, para los tests de integración Loader -> Extractor."""

    def setUp(self) -> None:
        self.tmp_dir = Path(tempfile.mkdtemp(prefix="extractor_tests_"))
        self.extractor = TextExtractor()

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp_dir, ignore_errors=True)


class TestIntegrationWithLoaders(ExtractorIntegrationTestCase):
    def test_pdf_loader_then_extractor(self) -> None:
        path = self.tmp_dir / "reporte.pdf"
        pdf_canvas = canvas.Canvas(str(path), pagesize=letter)
        text_object = pdf_canvas.beginText(40, letter[1] - 50)
        text_object.setFont("Helvetica", 11)
        for line in ["FINANCIAL HIGHLIGHTS", "Revenue: $482 million"]:
            text_object.textLine(line)
        pdf_canvas.drawText(text_object)
        pdf_canvas.save()

        raw_text = PDFLoader(path).load()
        clean_text = self.extractor.extract(raw_text)

        self.assertIn("--- Sección 1 ---", clean_text)
        self.assertIn("# FINANCIAL HIGHLIGHTS", clean_text)
        self.assertIn("Revenue: $482 million", clean_text)

    def test_docx_loader_then_extractor(self) -> None:
        path = self.tmp_dir / "reporte.docx"
        document = Document()
        document.add_heading("Resultados Q2 2026", level=1)
        document.add_paragraph("Revenue: $482 million")
        document.save(str(path))

        raw_text = DOCXLoader(path).load()
        clean_text = self.extractor.extract(raw_text)

        self.assertIn("# Resultados Q2 2026", clean_text)
        self.assertIn("Revenue: $482 million", clean_text)

    def test_pptx_loader_then_extractor(self) -> None:
        path = self.tmp_dir / "reporte.pptx"
        presentation = Presentation()
        layout = presentation.slide_layouts[1]
        slide = presentation.slides.add_slide(layout)
        slide.shapes.title.text = "Guidance"
        slide.placeholders[1].text_frame.text = "FY guidance raised."
        presentation.save(str(path))

        raw_text = PPTXLoader(path).load()
        clean_text = self.extractor.extract(raw_text)

        self.assertIn("--- Sección 1 ---", clean_text)
        self.assertIn("# Guidance", clean_text)

    def test_txt_loader_then_extractor(self) -> None:
        path = self.tmp_dir / "reporte.txt"
        path.write_text(
            "RISK FACTORS\nMacro headwinds could affect the second half.",
            encoding="utf-8",
        )

        raw_text = TXTLoader(path).load()
        clean_text = self.extractor.extract(raw_text)

        self.assertIn("# RISK FACTORS", clean_text)

    def test_raw_text_loader_then_extractor(self) -> None:
        raw_text = RawTextLoader(
            "Revenue:   $100M pegado a mano, sin ningún archivo de por medio."
        ).load()
        clean_text = self.extractor.extract(raw_text)

        self.assertIn("Revenue: $100M", clean_text)


if __name__ == "__main__":
    unittest.main()
