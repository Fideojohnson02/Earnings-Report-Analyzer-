"""
Pruebas del Financial Candidate Finder (FCF).

Cubre los 20 casos obligatorios definidos en el prompt del FCF:
detección simple y de variantes, no descarte de subtipos, conservación
de oración completa, múltiples candidatos por oración, múltiples
apariciones en oraciones distintas, ausencia de duplicaciones
accidentales, tablas, Estimated Input Tokens, Candidates Found, y la
ausencia explícita de toda responsabilidad que NO le corresponde al
FCF (llamadas a LLM, interpretación lingüística/económica/numérica,
clasificación de subtipos, scoring, signos, invención de información).

Cómo correr solo este archivo:

    python -m unittest tests.test_financial_candidate_finder -v
"""

import inspect
import unittest
from typing import Dict, List, Optional

from src.document_analysis.models import Paragraph
from src.financial_candidate_finder import candidate_finder as candidate_finder_module
from src.financial_candidate_finder.candidate_finder import FinancialCandidateFinder
from src.financial_candidate_finder.models import FCFResult, FinancialCandidate
from src.financial_candidate_finder.token_estimator import estimate_tokens_for_contexts

# Vocabulario reducido y controlado para tests unitarios -- no depende
# del contenido real de Financial_Terms_Synonyms.txt, que se prueba
# por separado en test_fcf_vocabulary.py.
_TEST_VOCABULARY: Dict[str, List[str]] = {
    "REVENUE": ["revenue", "revenues", "net revenue", "total revenue"],
    "NET_LOSS": ["net loss"],
    "GUIDANCE": ["guidance", "outlook"],
}


def _paragraph(
    index: int,
    text: str,
    heading: Optional[str] = None,
    section: Optional[int] = 1,
    is_table: bool = False,
) -> Paragraph:
    return Paragraph(
        index=index, section_number=section, heading=heading, text=text, is_table=is_table
    )


def _make_finder(vocabulary: Optional[Dict[str, List[str]]] = None) -> FinancialCandidateFinder:
    return FinancialCandidateFinder(vocabulary=vocabulary or _TEST_VOCABULARY)


class _FakeAnalysisResult:
    """Doble simple de `DocumentAnalysisResult` para no depender del
    Document Analyzer real en estos tests unitarios."""

    def __init__(self, paragraphs: List[Paragraph]) -> None:
        self.paragraphs = paragraphs


# 1. Detección de un Financial Term simple.
class TestSimpleDetection(unittest.TestCase):
    def test_detects_simple_financial_term(self) -> None:
        finder = _make_finder()
        result = finder.find_candidates(
            _FakeAnalysisResult([_paragraph(0, "Revenue was $500M.")])
        )

        self.assertEqual(result.candidates_found, 1)
        candidate = result.candidates[0]
        self.assertEqual(candidate.matched_metric, "REVENUE")
        self.assertEqual(candidate.matched_term, "revenue")
        self.assertEqual(candidate.matched_text, "Revenue")


# 2. Detección de variantes definidas en el vocabulario.
class TestVariantDetection(unittest.TestCase):
    def test_detects_plural_variant(self) -> None:
        finder = _make_finder()
        result = finder.find_candidates(
            _FakeAnalysisResult([_paragraph(0, "Revenues grew across all segments.")])
        )

        self.assertEqual(result.candidates_found, 1)
        self.assertEqual(result.candidates[0].matched_term, "revenues")

    def test_detects_multiword_variant(self) -> None:
        finder = _make_finder()
        result = finder.find_candidates(
            _FakeAnalysisResult([_paragraph(0, "Net revenue increased 10% this quarter.")])
        )

        self.assertEqual(result.candidates_found, 1)
        self.assertEqual(result.candidates[0].matched_term, "net revenue")

    def test_case_insensitive(self) -> None:
        finder = _make_finder()
        result = finder.find_candidates(
            _FakeAnalysisResult([_paragraph(0, "REVENUE was strong this quarter.")])
        )

        self.assertEqual(result.candidates_found, 1)
        self.assertEqual(result.candidates[0].matched_metric, "REVENUE")


# 3 y 4. Término acompañado de un subtipo -- no debe descartarse ni
# reclasificarse.
class TestSubtypesAreNotDiscardedOrReclassified(unittest.TestCase):
    def test_detects_term_with_subtype_and_keeps_general_category(self) -> None:
        finder = _make_finder()
        sentence = "Our data center SSD revenue exceeded $5 billion."
        result = finder.find_candidates(_FakeAnalysisResult([_paragraph(0, sentence)]))

        self.assertEqual(result.candidates_found, 1)
        candidate = result.candidates[0]
        self.assertEqual(candidate.matched_metric, "REVENUE")
        self.assertEqual(candidate.evidence, sentence)

    def test_multiple_subtypes_all_detected_under_same_category(self) -> None:
        finder = _make_finder()
        paragraphs = [
            _paragraph(0, "Subscription revenue increased 20%."),
            _paragraph(1, "Product revenue declined."),
        ]
        result = finder.find_candidates(_FakeAnalysisResult(paragraphs))

        self.assertEqual(result.candidates_found, 2)
        self.assertTrue(all(c.matched_metric == "REVENUE" for c in result.candidates))


# 5. Conservación de la oración completa.
class TestFullSentenceContextPreserved(unittest.TestCase):
    def test_context_is_the_full_sentence_not_a_fragment(self) -> None:
        finder = _make_finder()
        paragraph_text = (
            "This was a strong quarter overall. "
            "For the quarter, revenue increased 10% to $500M compared with "
            "$450M in the prior-year period. "
            "Management remains optimistic about next year."
        )
        result = finder.find_candidates(
            _FakeAnalysisResult([_paragraph(0, paragraph_text)])
        )

        self.assertEqual(result.candidates_found, 1)
        context = result.candidates[0].evidence
        self.assertEqual(
            context,
            "For the quarter, revenue increased 10% to $500M compared with "
            "$450M in the prior-year period.",
        )
        self.assertNotIn("strong quarter overall", context)
        self.assertNotIn("Management remains optimistic", context)


# 6. Múltiples Financial Terms en una misma oración.
class TestMultipleTermsInSameSentence(unittest.TestCase):
    def test_two_categories_in_one_sentence_produce_two_candidates(self) -> None:
        finder = _make_finder()
        sentence = "Revenue and net loss rose and decreased, 10% and 24% to 500M respectively."
        result = finder.find_candidates(_FakeAnalysisResult([_paragraph(0, sentence)]))

        self.assertEqual(result.candidates_found, 2)
        metrics = {c.matched_metric for c in result.candidates}
        self.assertEqual(metrics, {"REVENUE", "NET_LOSS"})
        # Ambos candidatos comparten la misma oración como contexto --
        # el FCF no intenta separar qué porcentaje es de cada uno.
        self.assertTrue(all(c.evidence == sentence for c in result.candidates))


# 7. Múltiples apariciones del mismo término en distintas oraciones.
class TestMultipleOccurrencesAcrossSentences(unittest.TestCase):
    def test_same_term_in_different_sentences_both_kept(self) -> None:
        finder = _make_finder()
        paragraph_text = "Revenue grew 10% in Q1. Later, revenue declined 5% in Q2."
        result = finder.find_candidates(
            _FakeAnalysisResult([_paragraph(0, paragraph_text)])
        )

        self.assertEqual(result.candidates_found, 2)
        contexts = {c.evidence for c in result.candidates}
        self.assertEqual(
            contexts,
            {"Revenue grew 10% in Q1.", "Later, revenue declined 5% in Q2."},
        )

    def test_same_term_twice_in_one_sentence_both_kept(self) -> None:
        finder = _make_finder()
        sentence = "Revenue increased in Q1, and revenue declined in Q2."

        result = finder.find_candidates(_FakeAnalysisResult([_paragraph(0, sentence)]))

        self.assertEqual(result.candidates_found, 2)
        self.assertEqual(len(result.evidence_groups), 1)
        self.assertEqual(result.evidence_groups[0].candidate_ids, (0, 1))

    def test_same_term_across_different_paragraphs_both_kept(self) -> None:
        finder = _make_finder()
        paragraphs = [
            _paragraph(0, "Revenue increased 14% this quarter."),
            _paragraph(1, "Our culture remains a top priority."),
            _paragraph(2, "Revenue also grew in the international segment."),
        ]
        result = finder.find_candidates(_FakeAnalysisResult(paragraphs))

        self.assertEqual(result.candidates_found, 2)


# 8. Ausencia de duplicaciones accidentales de una misma coincidencia.
class TestNoAccidentalDuplicates(unittest.TestCase):
    def test_no_duplicate_candidates_for_identical_match(self) -> None:
        finder = _make_finder()
        result = finder.find_candidates(
            _FakeAnalysisResult([_paragraph(0, "Revenue was $500M this quarter.")])
        )

        keys = {
            (c.paragraph_index, c.matched_metric, c.matched_term, c.evidence)
            for c in result.candidates
        }
        self.assertEqual(len(keys), len(result.candidates))

    def test_overlapping_vocabulary_terms_in_same_category_not_double_counted(self) -> None:
        # "net revenue" y "revenue" son ambos términos válidos de la
        # categoría REVENUE. Sobre el mismo tramo físico de texto, el
        # término más largo debe ganar y no generar un segundo
        # candidato para el término más corto contenido en él.
        finder = _make_finder()
        result = finder.find_candidates(
            _FakeAnalysisResult([_paragraph(0, "Net revenue increased this quarter.")])
        )

        self.assertEqual(result.candidates_found, 1)
        self.assertEqual(result.candidates[0].matched_term, "net revenue")


# 9 y 10. Detección y conservación de contexto en tablas.
class TestTableHandling(unittest.TestCase):
    def test_detects_financial_term_inside_table_text(self) -> None:
        finder = _make_finder()
        table_text = "[Tabla 1]\nRevenue | Q1 | Q2\n500M | 550M"
        result = finder.find_candidates(
            _FakeAnalysisResult([_paragraph(0, table_text, is_table=True)])
        )

        self.assertEqual(result.candidates_found, 1)
        candidate = result.candidates[0]
        self.assertEqual(candidate.matched_metric, "REVENUE")
        self.assertTrue(candidate.is_table)

    def test_table_context_is_the_full_table_block(self) -> None:
        finder = _make_finder()
        table_text = "[Tabla 1]\nRevenue | Q1 | Q2\n500M | 550M"
        result = finder.find_candidates(
            _FakeAnalysisResult([_paragraph(0, table_text, is_table=True)])
        )

        self.assertEqual(result.candidates[0].evidence, table_text)


# 11. Cálculo de Estimated Input Tokens sobre el texto seleccionado.
class TestEstimatedInputTokens(unittest.TestCase):
    def test_estimated_tokens_reflects_selected_context_only(self) -> None:
        finder = _make_finder()
        sentence = "Revenue was $500M this quarter."
        unrelated_sentence = "The weather in the region was mild this year."
        paragraph_text = f"{unrelated_sentence} {sentence}"

        result = finder.find_candidates(
            _FakeAnalysisResult([_paragraph(0, paragraph_text)])
        )

        expected = estimate_tokens_for_contexts([sentence])
        self.assertEqual(result.estimated_input_tokens, expected)
        # El texto no seleccionado (sin ningún término financiero) no
        # debe sumar a la estimación.
        self.assertLess(
            result.estimated_input_tokens,
            estimate_tokens_for_contexts([paragraph_text]),
        )

    def test_shared_context_counted_once(self) -> None:
        finder = _make_finder()
        sentence = "Revenue and net loss rose and decreased, 10% and 24% to 500M respectively."
        result = finder.find_candidates(_FakeAnalysisResult([_paragraph(0, sentence)]))

        self.assertEqual(result.candidates_found, 2)
        self.assertEqual(result.estimated_input_tokens, estimate_tokens_for_contexts([sentence]))


# 12. Generación correcta de Candidates Found.
class TestCandidatesFound(unittest.TestCase):
    def test_candidates_found_matches_candidate_list_length(self) -> None:
        finder = _make_finder()
        paragraphs = [
            _paragraph(0, "Revenue grew 10%."),
            _paragraph(1, "Guidance was raised for next year."),
        ]
        result = finder.find_candidates(_FakeAnalysisResult(paragraphs))

        self.assertEqual(result.candidates_found, len(result.candidates))

    def test_candidates_found_is_zero_when_no_terms_present(self) -> None:
        finder = _make_finder()
        result = finder.find_candidates(
            _FakeAnalysisResult([_paragraph(0, "Our culture remains a top priority.")])
        )

        self.assertEqual(result.candidates_found, 0)
        self.assertEqual(result.candidates, [])


# 13. Ausencia de llamadas al LLM.
class TestNoLLMCalls(unittest.TestCase):
    def test_module_does_not_reference_any_llm_or_http_client(self) -> None:
        source = inspect.getsource(candidate_finder_module)
        forbidden_tokens = ["anthropic", "openai", "requests", "httpx", "api_key", "client.messages"]
        lowered_source = source.lower()
        for token in forbidden_tokens:
            self.assertNotIn(token, lowered_source)

    def test_finder_has_no_method_that_executes_anything_external(self) -> None:
        public_methods = [
            name
            for name in dir(FinancialCandidateFinder)
            if not name.startswith("_") and callable(getattr(FinancialCandidateFinder, name))
        ]
        self.assertEqual(public_methods, ["find_candidates"])


# 14-19. Ausencia estructural de toda responsabilidad que no le
# corresponde al FCF: interpretación lingüística, económica, de
# números, clasificación de subtipos, scoring y asignación de signos.
# Se verifica a nivel de estructura de datos: si estos campos no
# existen, el FCF no puede estar calculándolos en ningún lado.
class TestNoInterpretationResponsibilities(unittest.TestCase):
    _FORBIDDEN_CANDIDATE_FIELDS = {
        "direction",
        "current_value",
        "previous_value",
        "percentage_variation",
        "numerical_variation",
        "temporal_context",
        "financial_value_sign",
        "sign",
        "score",
        "good_bad",
        "favorable",
        "decision",
    }

    def test_financial_candidate_has_no_forbidden_fields(self) -> None:
        actual_fields = set(FinancialCandidate.__dataclass_fields__.keys())
        self.assertTrue(actual_fields.isdisjoint(self._FORBIDDEN_CANDIDATE_FIELDS))

    def test_fcf_result_has_no_scoring_or_decision_fields(self) -> None:
        actual_fields = set(FCFResult.__dataclass_fields__.keys())
        forbidden = {"score", "decision", "long_short_no_operar", "signal"}
        self.assertTrue(actual_fields.isdisjoint(forbidden))

    def test_direction_synonyms_are_not_normalized(self) -> None:
        # "grew" y "declined" son sinónimos de movimiento -- el FCF no
        # debe convertirlos a ningún valor común (ej. INCREASED).
        finder = _make_finder()
        paragraphs = [
            _paragraph(0, "Revenue grew 15% this quarter."),
            _paragraph(1, "Revenue declined 8% in the prior quarter."),
        ]
        result = finder.find_candidates(_FakeAnalysisResult(paragraphs))

        for candidate in result.candidates:
            # matched_text es literalmente "Revenue", nunca una
            # palabra que indique dirección.
            self.assertEqual(candidate.matched_text, "Revenue")
        self.assertFalse(hasattr(result.candidates[0], "direction"))

    def test_numbers_in_context_are_not_parsed_or_extracted(self) -> None:
        finder = _make_finder()
        sentence = "Revenue increased 10% to $500M compared with $450M last year."
        result = finder.find_candidates(_FakeAnalysisResult([_paragraph(0, sentence)]))

        candidate = result.candidates[0]
        # El único lugar donde deberían aparecer los números es dentro
        # del contexto textual completo, nunca en un campo estructurado.
        self.assertIn("$500M", candidate.evidence)
        self.assertFalse(hasattr(candidate, "current_value"))
        self.assertFalse(hasattr(candidate, "previous_value"))


# 20. Ausencia de información inventada.
class TestNoInventedInformation(unittest.TestCase):
    def test_matched_text_is_always_a_literal_substring_of_the_context(self) -> None:
        finder = _make_finder()
        paragraphs = [
            _paragraph(0, "Revenue was $500M."),
            _paragraph(1, "Our data center SSD revenue exceeded $5 billion."),
            _paragraph(2, "[Tabla 1]\nRevenue | Q1\n500M", is_table=True),
        ]
        result = finder.find_candidates(_FakeAnalysisResult(paragraphs))

        for candidate in result.candidates:
            self.assertIn(candidate.matched_text, candidate.evidence)

    def test_no_candidate_generated_for_text_without_financial_terms(self) -> None:
        finder = _make_finder()
        result = finder.find_candidates(
            _FakeAnalysisResult(
                [_paragraph(0, "Employees enjoyed the company picnic last Friday.")]
            )
        )

        self.assertEqual(result.candidates, [])

    def test_never_fabricates_a_term_not_present_in_vocabulary(self) -> None:
        finder = _make_finder()
        result = finder.find_candidates(
            _FakeAnalysisResult([_paragraph(0, "EBITDA margin expanded significantly.")])
        )

        # "EBITDA" no está en el vocabulario de prueba -- no debe
        # aparecer ningún candidato inventado para él.
        self.assertEqual(result.candidates, [])


if __name__ == "__main__":
    unittest.main()
