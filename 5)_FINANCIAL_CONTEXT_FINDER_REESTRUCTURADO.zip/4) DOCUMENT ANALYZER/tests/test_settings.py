"""
Pruebas unitarias del módulo `src/config/settings.py`.

"Prueba unitaria" (unit test) significa: una función chiquita que
ejecuta una parte puntual del código y verifica (con `assert`) que el
resultado sea el esperado. Usamos `unittest`, que viene incluido con
Python (no hace falta instalar nada aparte).

Cómo correr solo este archivo:

    python -m unittest tests.test_settings -v
"""

import os
import unittest
from pathlib import Path

from src.config.settings import ConfigError, _load_settings_from_env

# Variables de entorno que estas pruebas van a modificar temporalmente.
_ENV_VARS_UNDER_TEST = [
    "ENVIRONMENT",
    "LOG_LEVEL",
    "LOG_DIR",
    "DATA_INPUT_DIR",
    "DATA_OUTPUT_DIR",
    "ANTHROPIC_API_KEY",
    "FINANCIAL_TERMS_PATH",
]


class TestSettings(unittest.TestCase):
    def setUp(self) -> None:
        # Guardamos el valor original de cada variable (o None si no
        # existía) para poder restaurarlo después de cada prueba y no
        # afectar a las demás pruebas ni al resto del sistema.
        self._original_env = {
            key: os.environ.get(key) for key in _ENV_VARS_UNDER_TEST
        }
        for key in _ENV_VARS_UNDER_TEST:
            os.environ.pop(key, None)

    def tearDown(self) -> None:
        for key, value in self._original_env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value

    def test_default_values_when_no_env_vars_set(self) -> None:
        settings = _load_settings_from_env()

        self.assertEqual(settings.environment, "development")
        self.assertEqual(settings.log_level, "INFO")
        self.assertEqual(settings.log_dir, Path("logs"))
        self.assertEqual(settings.data_input_dir, Path("data/inputs"))
        self.assertEqual(settings.data_output_dir, Path("data/outputs"))
        self.assertIsNone(settings.anthropic_api_key)
        self.assertEqual(
            settings.financial_terms_path,
            Path("data/financial_terms/Financial_Terms_Synonyms.txt"),
        )

    def test_env_vars_override_defaults(self) -> None:
        os.environ["ENVIRONMENT"] = "production"
        os.environ["LOG_LEVEL"] = "debug"  # minúsculas a propósito
        os.environ["LOG_DIR"] = "custom_logs"
        os.environ["ANTHROPIC_API_KEY"] = "clave-de-prueba"
        os.environ["FINANCIAL_TERMS_PATH"] = "custom/terms.txt"

        settings = _load_settings_from_env()

        self.assertEqual(settings.environment, "production")
        self.assertEqual(settings.log_level, "DEBUG")  # se normaliza a mayúsculas
        self.assertEqual(settings.log_dir, Path("custom_logs"))
        self.assertEqual(settings.anthropic_api_key, "clave-de-prueba")
        self.assertEqual(settings.financial_terms_path, Path("custom/terms.txt"))

    def test_invalid_log_level_raises_config_error(self) -> None:
        os.environ["LOG_LEVEL"] = "NO_ES_UN_NIVEL_VALIDO"

        with self.assertRaises(ConfigError):
            _load_settings_from_env()

    def test_settings_object_is_immutable(self) -> None:
        settings = _load_settings_from_env()

        with self.assertRaises(Exception):
            # `frozen=True` en el dataclass debe impedir esta asignación.
            settings.environment = "otro_valor"  # type: ignore[misc]


if __name__ == "__main__":
    unittest.main()
