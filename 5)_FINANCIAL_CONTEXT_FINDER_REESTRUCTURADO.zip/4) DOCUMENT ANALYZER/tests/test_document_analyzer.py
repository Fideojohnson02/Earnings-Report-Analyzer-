"""Pruebas del Document Analyzer estructural.

El Document Analyzer no busca términos financieros. Solo segmenta,
preserva metadata y linealiza headings dentro del texto de cada bloque.
"""

import unittest

from src.document_analysis.document_analyzer import DocumentAnalyzer
from src.document_analysis.paragraph_segmenter import segment_into_paragraphs


class TestHeadingLinearization(unittest.TestCase):
    def test_heading_is_embedded_in_following_paragraph(self) -> None:
        text = "# Revenue\nIt was 10% higher, to 100B."
        paragraphs = segment_into_paragraphs(text)

        self.assertEqual(len(paragraphs), 1)
        self.assertEqual(paragraphs[0].heading, "Revenue")
        self.assertEqual(
            paragraphs[0].text,
            "Revenue: [It was 10% higher, to 100B.]",
        )

    def test_heading_applies_to_each_block_until_next_heading(self) -> None:
        text = "# Outlook\nFirst paragraph.\n\nSecond paragraph.\n\n# Risks\nRisk paragraph."
        paragraphs = segment_into_paragraphs(text)

        self.assertEqual(
            [paragraph.text for paragraph in paragraphs],
            [
                "Outlook: [First paragraph.]",
                "Outlook: [Second paragraph.]",
                "Risks: [Risk paragraph.]",
            ],
        )

    def test_heading_is_embedded_in_table_evidence(self) -> None:
        text = "# Results\n[Tabla 1]\nRevenue | 100B"
        paragraphs = segment_into_paragraphs(text)

        self.assertEqual(len(paragraphs), 1)
        self.assertTrue(paragraphs[0].is_table)
        self.assertEqual(
            paragraphs[0].text,
            "Results: [[Tabla 1]\nRevenue | 100B]",
        )


class TestStructuralBoundaries(unittest.TestCase):
    def test_section_marker_flushes_previous_block_without_blank_line(self) -> None:
        text = (
            "--- Sección 1 ---\n"
            "# Outlook\n"
            "Guidance raised.\n"
            "--- Sección 2 ---\n"
            "Revenue increased."
        )
        paragraphs = segment_into_paragraphs(text)

        self.assertEqual(len(paragraphs), 2)
        self.assertEqual(paragraphs[0].section_number, 1)
        self.assertEqual(paragraphs[0].text, "Outlook: [Guidance raised.]")
        self.assertEqual(paragraphs[1].section_number, 2)
        self.assertIsNone(paragraphs[1].heading)
        self.assertEqual(paragraphs[1].text, "Revenue increased.")

    def test_heading_does_not_leak_into_next_section(self) -> None:
        text = (
            "--- Sección 1 ---\n"
            "# Outlook\n"
            "Guidance raised.\n\n"
            "--- Sección 2 ---\n"
            "Revenue increased."
        )
        paragraphs = segment_into_paragraphs(text)

        self.assertEqual(paragraphs[1].heading, None)
        self.assertEqual(paragraphs[1].text, "Revenue increased.")

    def test_table_is_its_own_structural_block(self) -> None:
        text = "Some text.\n[Tabla 1]\nRevenue | $482M\nMore text."
        paragraphs = segment_into_paragraphs(text)

        self.assertEqual(len(paragraphs), 3)
        self.assertFalse(paragraphs[0].is_table)
        self.assertTrue(paragraphs[1].is_table)
        self.assertIn("Revenue | $482M", paragraphs[1].text)
        self.assertFalse(paragraphs[2].is_table)


class TestDocumentAnalyzerIntegration(unittest.TestCase):
    def test_result_contains_only_document_structure(self) -> None:
        text = "# Financial Highlights\nRevenue increased 14%."
        result = DocumentAnalyzer().analyze(text)

        self.assertEqual(result.original_text, text)
        self.assertEqual(len(result.paragraphs), 1)
        self.assertEqual(result.paragraphs[0].text, "Financial Highlights: [Revenue increased 14%.]")
        self.assertFalse(hasattr(result, "candidates"))

    def test_document_without_headings_still_segments(self) -> None:
        result = DocumentAnalyzer().analyze(
            "We value our team.\n\nRevenue increased 14%."
        )

        self.assertEqual(len(result.paragraphs), 2)
        self.assertIsNone(result.paragraphs[0].heading)
        self.assertIsNone(result.paragraphs[1].heading)


if __name__ == "__main__":
    unittest.main()