"""
Pruebas del parseo del vocabulario financiero (`vocabulary.py`).

Cómo correr solo este archivo:

    python -m unittest tests.test_fcf_vocabulary -v
"""

import shutil
import tempfile
import unittest
from pathlib import Path

from src.financial_candidate_finder.vocabulary import (
    VocabularyLoadError,
    _parse_vocabulary,
    load_financial_terms_vocabulary,
)

_SAMPLE_FILE = """FINANCIAL TERMS CORE — DESGLOSE DE TÉRMINOS Y SINÓNIMOS
AI Earnings Analyzer

============================================================
CATEGORÍA: REVENUE
============================================================
revenue
revenues
net sales

============================================================
CATEGORÍA: EPS
============================================================
EPS
earnings per share
"""


class TestParseVocabulary(unittest.TestCase):
    def test_parses_categories_and_terms(self) -> None:
        vocabulary = _parse_vocabulary(_SAMPLE_FILE)

        self.assertIn("REVENUE", vocabulary)
        self.assertIn("EPS", vocabulary)
        self.assertEqual(vocabulary["REVENUE"], ["revenue", "revenues", "net sales"])
        self.assertEqual(vocabulary["EPS"], ["EPS", "earnings per share"])

    def test_ignores_title_lines_before_first_category(self) -> None:
        vocabulary = _parse_vocabulary(_SAMPLE_FILE)
        all_terms = [term for terms in vocabulary.values() for term in terms]

        self.assertNotIn("FINANCIAL TERMS CORE — DESGLOSE DE TÉRMINOS Y SINÓNIMOS", all_terms)
        self.assertNotIn("AI Earnings Analyzer", all_terms)

    def test_ignores_separator_lines(self) -> None:
        vocabulary = _parse_vocabulary(_SAMPLE_FILE)
        all_terms = [term for terms in vocabulary.values() for term in terms]

        self.assertFalse(any(term.startswith("=") for term in all_terms))

    def test_empty_category_is_discarded(self) -> None:
        text = (
            "============================================================\n"
            "CATEGORÍA: SIN_TERMINOS\n"
            "============================================================\n"
            "============================================================\n"
            "CATEGORÍA: REVENUE\n"
            "============================================================\n"
            "revenue\n"
        )
        vocabulary = _parse_vocabulary(text)

        self.assertNotIn("SIN_TERMINOS", vocabulary)
        self.assertIn("REVENUE", vocabulary)

    def test_does_not_modify_category_names(self) -> None:
        text = (
            "============================================================\n"
            "CATEGORÍA: FREE CASH FLOW (FCF)\n"
            "============================================================\n"
            "free cash flow\n"
        )
        vocabulary = _parse_vocabulary(text)

        # No se renombra ni se abrevia la categoría tal cual figura en
        # el archivo fuente.
        self.assertIn("FREE CASH FLOW (FCF)", vocabulary)


class TestLoadFinancialTermsVocabulary(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp_dir = Path(tempfile.mkdtemp())

    def tearDown(self) -> None:
        shutil.rmtree(self._tmp_dir, ignore_errors=True)

    def test_loads_from_explicit_path(self) -> None:
        file_path = self._tmp_dir / "terms.txt"
        file_path.write_text(_SAMPLE_FILE, encoding="utf-8")

        vocabulary = load_financial_terms_vocabulary(path=file_path)

        self.assertIn("REVENUE", vocabulary)
        self.assertIn("EPS", vocabulary)

    def test_missing_file_raises_vocabulary_load_error(self) -> None:
        missing_path = self._tmp_dir / "does_not_exist.txt"

        with self.assertRaises(VocabularyLoadError):
            load_financial_terms_vocabulary(path=missing_path)

    def test_file_without_categories_raises_vocabulary_load_error(self) -> None:
        file_path = self._tmp_dir / "empty.txt"
        file_path.write_text("Solo texto suelto, sin categorías.\n", encoding="utf-8")

        with self.assertRaises(VocabularyLoadError):
            load_financial_terms_vocabulary(path=file_path)

    def test_loads_real_project_vocabulary_file(self) -> None:
        # Integración: el archivo real del proyecto debe poder
        # cargarse y debe contener las 17 categorías acordadas.
        real_path = Path("data/financial_terms/Financial_Terms_Synonyms.txt")
        vocabulary = load_financial_terms_vocabulary(path=real_path)

        self.assertEqual(len(vocabulary), 17)
        self.assertIn("REVENUE", vocabulary)
        self.assertIn("GUIDANCE", vocabulary)
        self.assertIn("OPERATING CASH FLOW", vocabulary)


if __name__ == "__main__":
    unittest.main()
