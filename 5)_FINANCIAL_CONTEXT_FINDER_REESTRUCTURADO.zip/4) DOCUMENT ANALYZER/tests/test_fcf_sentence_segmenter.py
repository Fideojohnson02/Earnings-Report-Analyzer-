"""
Pruebas del segmentador de oraciones (`sentence_segmenter.py`).

Cómo correr solo este archivo:

    python -m unittest tests.test_fcf_sentence_segmenter -v
"""

import unittest

from src.financial_candidate_finder.sentence_segmenter import split_into_sentences


class TestSplitIntoSentences(unittest.TestCase):
    def test_empty_text_returns_empty_list(self) -> None:
        self.assertEqual(split_into_sentences(""), [])
        self.assertEqual(split_into_sentences("   "), [])

    def test_single_sentence_returned_whole(self) -> None:
        text = "Revenue increased 10% this quarter."
        self.assertEqual(split_into_sentences(text), [text])

    def test_splits_two_sentences(self) -> None:
        text = "Revenue increased 10%. Net income declined 5%."
        sentences = split_into_sentences(text)

        self.assertEqual(
            sentences,
            ["Revenue increased 10%.", "Net income declined 5%."],
        )

    def test_does_not_split_on_decimal_numbers(self) -> None:
        text = "Free cash flow was $450.5 million, up from $400.2 million."
        sentences = split_into_sentences(text)

        self.assertEqual(len(sentences), 1)
        self.assertIn("$450.5 million", sentences[0])
        self.assertIn("$400.2 million", sentences[0])

    def test_does_not_split_on_common_abbreviations(self) -> None:
        text = "Our subsidiary, Acme Corp., reported strong growth. Revenue rose 8%."
        sentences = split_into_sentences(text)

        self.assertEqual(len(sentences), 2)
        self.assertIn("Acme Corp.", sentences[0])

    def test_does_not_split_on_us_abbreviation(self) -> None:
        text = "Sales in the U.S. grew 12%. International sales declined."
        sentences = split_into_sentences(text)

        self.assertEqual(len(sentences), 2)
        self.assertTrue(sentences[0].startswith("Sales in the U.S. grew 12%."))

    def test_period_followed_by_number_does_not_end_evidence(self) -> None:
        text = "Margins improved significantly. 10% growth was reported in the segment."
        sentences = split_into_sentences(text)

        self.assertEqual(sentences, [text])

    def test_new_line_is_always_a_new_evidence(self) -> None:
        text = "Revenue increased 10%.\nnet income declined 5%."
        self.assertEqual(
            split_into_sentences(text),
            ["Revenue increased 10%.", "net income declined 5%."],
        )

    def test_new_line_with_bullet_is_always_a_new_evidence(self) -> None:
        text = "Revenue increased 10%.\n* net income declined 5%."
        self.assertEqual(
            split_into_sentences(text),
            ["Revenue increased 10%.", "* net income declined 5%."],
        )

    def test_lowercase_after_period_on_same_line_is_not_split(self) -> None:
        text = "Revenue increased 10%. net income declined 5%."
        self.assertEqual(split_into_sentences(text), [text])

    def test_abbreviation_matching_is_case_insensitive(self) -> None:
        text = "Our subsidiary, ACME CORP., reported strong growth. Revenue rose 8%."
        sentences = split_into_sentences(text)

        self.assertEqual(len(sentences), 2)
        self.assertIn("ACME CORP.", sentences[0])

    def test_preserves_full_sentence_text_without_alteration(self) -> None:
        text = "Revenue and net loss rose and decreased, 10% and 24% to 500M respectively."
        sentences = split_into_sentences(text)

        self.assertEqual(sentences, [text])


if __name__ == "__main__":
    unittest.main()
