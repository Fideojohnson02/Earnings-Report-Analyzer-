"""
Pruebas unitarias del módulo `src/logging_setup/logger.py`.

Cómo correr solo este archivo:

    python -m unittest tests.test_logger -v
"""

import logging
import shutil
import unittest
from pathlib import Path

from src.config.settings import Settings
from src.logging_setup import logger as logger_module


class TestLogging(unittest.TestCase):
    def setUp(self) -> None:
        self.test_log_dir = Path("tests/_tmp_logs")

        self.settings = Settings(
            environment="test",
            log_level="DEBUG",
            log_dir=self.test_log_dir,
            data_input_dir=Path("data/inputs"),
            data_output_dir=Path("data/outputs"),
            anthropic_api_key=None,
            financial_terms_path=Path(
                "data/financial_terms/Financial_Terms_Synonyms.txt"
            ),
        )

        # Reseteamos el estado del módulo antes de cada prueba, porque
        # `setup_logging` normalmente solo se ejecuta una vez.
        logger_module._reset_for_tests()

    def tearDown(self) -> None:
        logger_module._reset_for_tests()
        if self.test_log_dir.exists():
            shutil.rmtree(self.test_log_dir)

    def test_setup_logging_creates_log_file_with_message(self) -> None:
        logger_module.setup_logging(self.settings)
        logger = logger_module.get_logger("tests.test_logger")

        logger.info("mensaje de prueba")

        log_file = self.test_log_dir / "ai_earnings_analyzer.log"
        self.assertTrue(log_file.exists())
        self.assertIn("mensaje de prueba", log_file.read_text(encoding="utf-8"))

    def test_setup_logging_respects_log_level(self) -> None:
        logger_module.setup_logging(self.settings)
        root_logger = logging.getLogger()

        self.assertEqual(root_logger.level, logging.DEBUG)

    def test_setup_logging_is_idempotent(self) -> None:
        logger_module.setup_logging(self.settings)
        handlers_after_first_call = len(logging.getLogger().handlers)

        logger_module.setup_logging(self.settings)
        handlers_after_second_call = len(logging.getLogger().handlers)

        self.assertEqual(handlers_after_first_call, handlers_after_second_call)


if __name__ == "__main__":
    unittest.main()
