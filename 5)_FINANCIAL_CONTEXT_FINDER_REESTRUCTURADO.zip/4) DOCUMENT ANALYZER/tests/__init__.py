"""Suite de pruebas automáticas del proyecto."""
