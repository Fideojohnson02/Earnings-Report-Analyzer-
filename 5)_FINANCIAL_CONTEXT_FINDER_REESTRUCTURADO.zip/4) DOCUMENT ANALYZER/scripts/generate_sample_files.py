"""
Genera archivos de ejemplo (PDF, PPTX, DOCX, TXT) en `data/inputs/`,
con contenido y estructura parecidos a un earnings report real
(títulos, tablas, varias páginas/slides), para poder probar los
loaders sin depender de que consigas un reporte real.

Cómo ejecutarlo:

    python -m scripts.generate_sample_files
"""

from docx import Document
from pptx import Presentation
from pptx.util import Inches
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import (
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from src.config.settings import get_settings

BODY_LINES = [
    "Revenue: $482 million, up 14% year-over-year.",
    "EPS: $1.35 versus $1.10 in the prior-year quarter.",
    "Operating margin expanded to 22.4% from 19.8%.",
    "",
    "CEO comments: We are pleased with another quarter of double-digit "
    "growth, driven by strong demand in our cloud segment. We remain "
    "cautious about macro headwinds in the second half of the year.",
    "",
    "CFO comments: Free cash flow reached $95 million. We repurchased "
    "$50 million in shares during the quarter and raised our dividend "
    "by 8%.",
    "",
    "Guidance: We are raising full-year revenue guidance to $1.95-2.0 "
    "billion, from $1.85-1.95 billion previously.",
]

TABLE_DATA = [
    ["Metric", "Value"],
    ["Gross margin", "61.2%"],
    ["Net income", "$78 million"],
]


def _generate_txt(output_dir) -> None:
    path = output_dir / "sample_earnings.txt"
    lines = ["Acme Corp — Q2 2026 Earnings Release", ""] + BODY_LINES
    path.write_text("\n".join(lines), encoding="utf-8")
    print(f"Generado: {path}")


def _generate_pdf(output_dir) -> None:
    path = output_dir / "sample_earnings.pdf"
    styles = getSampleStyleSheet()
    doc = SimpleDocTemplate(str(path), pagesize=letter)

    story = [Paragraph("Acme Corp — Q2 2026 Earnings Release", styles["Title"])]
    for line in BODY_LINES:
        if line == "":
            story.append(Spacer(1, 8))
        else:
            story.append(Paragraph(line, styles["Normal"]))

    story.append(Spacer(1, 16))
    table = Table(TABLE_DATA, colWidths=[200, 150])
    table.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.5, colors.black),
                ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
            ]
        )
    )
    story.append(table)

    story.append(PageBreak())
    story.append(Paragraph("Risks and outlook", styles["Heading2"]))
    story.append(
        Paragraph(
            "Additional risk factors and outlook commentary continue "
            "on this second page.",
            styles["Normal"],
        )
    )

    doc.build(story)
    print(f"Generado: {path}")


def _generate_docx(output_dir) -> None:
    path = output_dir / "sample_earnings.docx"
    document = Document()

    document.add_heading("Acme Corp — Q2 2026 Earnings Release", level=1)
    document.add_paragraph(BODY_LINES[0])
    document.add_paragraph(BODY_LINES[1])

    document.add_heading("Resultados clave", level=2)
    table = document.add_table(rows=len(TABLE_DATA), cols=2)
    for row_index, row_data in enumerate(TABLE_DATA):
        table.rows[row_index].cells[0].text = row_data[0]
        table.rows[row_index].cells[1].text = row_data[1]

    document.add_heading("Comentarios del management", level=2)
    for line in BODY_LINES[4:]:
        if line:
            document.add_paragraph(line)

    document.save(str(path))
    print(f"Generado: {path}")


def _generate_pptx(output_dir) -> None:
    path = output_dir / "sample_earnings.pptx"
    presentation = Presentation()
    layout = presentation.slide_layouts[1]  # Título + contenido

    slide1 = presentation.slides.add_slide(layout)
    slide1.shapes.title.text = "Acme Corp — Q2 2026 Highlights"
    body1 = slide1.placeholders[1].text_frame
    body1.text = BODY_LINES[0]
    body1.add_paragraph().text = BODY_LINES[1]
    body1.add_paragraph().text = BODY_LINES[2]

    slide2 = presentation.slides.add_slide(layout)
    slide2.shapes.title.text = "Guidance"
    body2 = slide2.placeholders[1].text_frame
    body2.text = "FY guidance raised to $1.95-2.0 billion"

    rows, cols = len(TABLE_DATA), 2
    table_shape = slide2.shapes.add_table(
        rows, cols, Inches(1), Inches(3), Inches(6), Inches(1.5)
    )
    for row_index, row_data in enumerate(TABLE_DATA):
        table_shape.table.cell(row_index, 0).text = row_data[0]
        table_shape.table.cell(row_index, 1).text = row_data[1]

    presentation.save(str(path))
    print(f"Generado: {path}")


def main() -> None:
    settings = get_settings()
    output_dir = settings.data_input_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    _generate_txt(output_dir)
    _generate_pdf(output_dir)
    _generate_docx(output_dir)
    _generate_pptx(output_dir)


if __name__ == "__main__":
    main()
