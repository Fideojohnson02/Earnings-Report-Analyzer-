"""Scripts ejecutables sueltos, fuera del flujo principal del sistema."""
