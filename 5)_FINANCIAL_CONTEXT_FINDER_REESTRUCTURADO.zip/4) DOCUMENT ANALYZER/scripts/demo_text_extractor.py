"""
Script de demostración del módulo Extractor de texto.

Muestra la cadena completa Loader -> Extractor para los 4 archivos de
ejemplo, y evidencia lo que el Extractor unifica/limpia respecto al
texto crudo del Loader.

Corré primero, si no lo hiciste:

    python -m scripts.generate_sample_files

Luego:

    python -m scripts.demo_text_extractor
"""

from src.config.settings import get_settings
from src.loaders.base_loader import LoaderError
from src.loaders.loader_factory import get_loader_for_file
from src.logging_setup.logger import get_logger, setup_logging
from src.text_extraction.text_extractor import TextExtractionError, TextExtractor

_PREVIEW_CHAR_LIMIT = 1200


def _show(logger, label: str, text: str) -> None:
    logger.info("----- %s (%d caracteres) -----", label, len(text))
    preview = text if len(text) <= _PREVIEW_CHAR_LIMIT else text[:_PREVIEW_CHAR_LIMIT] + "\n... (truncado)"
    for line in preview.splitlines():
        logger.info(line)


def main() -> None:
    settings = get_settings()
    setup_logging(settings)
    logger = get_logger(__name__)
    extractor = TextExtractor()

    input_dir = settings.data_input_dir
    sample_files = [
        input_dir / "sample_earnings.pdf",
        input_dir / "sample_earnings.docx",
        input_dir / "sample_earnings.pptx",
        input_dir / "sample_earnings.txt",
    ]

    for file_path in sample_files:
        if not file_path.exists():
            logger.warning(
                "No se encontró %s. Corré primero: "
                "python -m scripts.generate_sample_files",
                file_path,
            )
            continue

        try:
            raw_text = get_loader_for_file(file_path).load()
            clean_text = extractor.extract(raw_text)
        except (LoaderError, TextExtractionError) as exc:
            logger.error("Error procesando %s: %s", file_path.name, exc)
            continue

        _show(logger, f"{file_path.name} (extraído y normalizado)", clean_text)


if __name__ == "__main__":
    main()
