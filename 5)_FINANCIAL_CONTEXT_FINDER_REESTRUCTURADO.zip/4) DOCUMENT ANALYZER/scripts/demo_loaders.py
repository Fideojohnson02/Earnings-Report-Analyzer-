"""
Script de demostración del módulo Loaders.

Antes de correr esto, generá los archivos de ejemplo (si todavía no
lo hiciste):

    python -m scripts.generate_sample_files

Luego:

    python -m scripts.demo_loaders
"""

from src.config.settings import get_settings
from src.loaders.base_loader import LoaderError
from src.loaders.loader_factory import get_loader_for_file, get_loader_for_pasted_text
from src.logging_setup.logger import get_logger, setup_logging

_PREVIEW_CHAR_LIMIT = 600


def _show(logger, label: str, text: str) -> None:
    logger.info("----- %s (%d caracteres extraídos) -----", label, len(text))
    preview = text if len(text) <= _PREVIEW_CHAR_LIMIT else text[:_PREVIEW_CHAR_LIMIT] + "\n... (truncado)"
    for line in preview.splitlines():
        logger.info(line)


def main() -> None:
    settings = get_settings()
    setup_logging(settings)
    logger = get_logger(__name__)

    input_dir = settings.data_input_dir
    sample_files = [
        input_dir / "sample_earnings.txt",
        input_dir / "sample_earnings.pdf",
        input_dir / "sample_earnings.docx",
        input_dir / "sample_earnings.pptx",
    ]

    # Mismo bucle, misma llamada (`get_loader_for_file(...).load()`)
    # para los cuatro formatos: esto es, en la práctica, la prueba de
    # que "todo termina procesado por el mismo motor".
    for file_path in sample_files:
        if not file_path.exists():
            logger.warning(
                "No se encontró %s. Corré primero: "
                "python -m scripts.generate_sample_files",
                file_path,
            )
            continue
        try:
            loader = get_loader_for_file(file_path)
            text = loader.load()
            _show(logger, file_path.name, text)
        except LoaderError as exc:
            logger.error("Error al cargar %s: %s", file_path.name, exc)

    pasted_text = "Texto pegado a mano.\nSegunda línea del texto pegado."
    loader = get_loader_for_pasted_text(pasted_text)
    _show(logger, "texto pegado", loader.load())


if __name__ == "__main__":
    main()
