"""
Script de demostración del módulo Document Analyzer.

Muestra la cadena completa Loader -> Extractor -> Document Analyzer
para los archivos de ejemplo, mostrando los párrafos estructurales y
los headings linealizados. La búsqueda financiera pertenece al
Financial Candidate Finder.

Corré primero, si no lo hiciste:

    python -m scripts.generate_sample_files

Luego:

    python -m scripts.demo_document_analyzer
"""

from src.config.settings import get_settings
from src.document_analysis.document_analyzer import DocumentAnalyzer
from src.loaders.base_loader import LoaderError
from src.loaders.loader_factory import get_loader_for_file
from src.logging_setup.logger import get_logger, setup_logging
from src.text_extraction.text_extractor import TextExtractionError, TextExtractor

_TEXT_PREVIEW_LIMIT = 160


def main() -> None:
    settings = get_settings()
    setup_logging(settings)
    logger = get_logger(__name__)
    extractor = TextExtractor()
    analyzer = DocumentAnalyzer()

    input_dir = settings.data_input_dir
    sample_files = [
        input_dir / "sample_earnings.pdf",
        input_dir / "sample_earnings.docx",
        input_dir / "sample_earnings.pptx",
        input_dir / "sample_earnings.txt",
    ]

    for file_path in sample_files:
        if not file_path.exists():
            logger.warning(
                "No se encontró %s. Corré primero: "
                "python -m scripts.generate_sample_files",
                file_path,
            )
            continue

        try:
            raw_text = get_loader_for_file(file_path).load()
            clean_text = extractor.extract(raw_text)
            result = analyzer.analyze(clean_text)
        except (LoaderError, TextExtractionError) as exc:
            logger.error("Error procesando %s: %s", file_path.name, exc)
            continue

        logger.info("===== %s =====", file_path.name)
        logger.info("Párrafos estructurales: %d", len(result.paragraphs))

        for paragraph in result.paragraphs:
            logger.info(
                "--- Párrafo #%d (sección %s, encabezado %r, tabla=%s) ---",
                paragraph.index,
                paragraph.section_number,
                paragraph.heading,
                paragraph.is_table,
            )
            logger.info(
                "Texto: %s",
                paragraph.text.replace("\n", " ")[:_TEXT_PREVIEW_LIMIT],
            )


if __name__ == "__main__":
    main()