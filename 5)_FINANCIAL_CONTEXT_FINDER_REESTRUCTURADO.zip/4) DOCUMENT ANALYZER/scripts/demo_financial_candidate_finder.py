"""
Script de demostración del Financial Candidate Finder (FCF).

Muestra la cadena completa Loader -> Extractor -> Document Analyzer ->
Financial Candidate Finder para los 4 archivos de ejemplo, mostrando
los candidatos detectados por el FCF (sin ninguna interpretación
económica, numérica ni de scoring: eso queda para etapas futuras).

Corré primero, si no lo hiciste:

    python -m scripts.generate_sample_files

Luego:

    python -m scripts.demo_financial_candidate_finder
"""

from src.config.settings import get_settings
from src.document_analysis.document_analyzer import DocumentAnalyzer
from src.financial_candidate_finder.candidate_finder import FinancialCandidateFinder
from src.financial_candidate_finder.vocabulary import VocabularyLoadError
from src.loaders.base_loader import LoaderError
from src.loaders.loader_factory import get_loader_for_file
from src.logging_setup.logger import get_logger, setup_logging
from src.text_extraction.text_extractor import TextExtractionError, TextExtractor

_TEXT_PREVIEW_LIMIT = 160


def main() -> None:
    settings = get_settings()
    setup_logging(settings)
    logger = get_logger(__name__)

    extractor = TextExtractor()
    analyzer = DocumentAnalyzer()

    try:
        finder = FinancialCandidateFinder()
    except VocabularyLoadError as exc:
        logger.error("No se pudo inicializar el Financial Candidate Finder: %s", exc)
        return

    input_dir = settings.data_input_dir
    sample_files = [
        input_dir / "sample_earnings.pdf",
        input_dir / "sample_earnings.docx",
        input_dir / "sample_earnings.pptx",
        input_dir / "sample_earnings.txt",
    ]

    for file_path in sample_files:
        if not file_path.exists():
            logger.warning(
                "No se encontró %s. Corré primero: "
                "python -m scripts.generate_sample_files",
                file_path,
            )
            continue

        try:
            raw_text = get_loader_for_file(file_path).load()
            clean_text = extractor.extract(raw_text)
            analysis_result = analyzer.analyze(clean_text)
            fcf_result = finder.find_candidates(analysis_result)
        except (LoaderError, TextExtractionError) as exc:
            logger.error("Error procesando %s: %s", file_path.name, exc)
            continue

        logger.info("===== %s =====", file_path.name)
        logger.info(
            "Candidates found: %d | Estimated input tokens: %d",
            fcf_result.candidates_found,
            fcf_result.estimated_input_tokens,
        )

        for candidate in fcf_result.candidates:
            logger.info(
                "--- Candidato #%d (%s / %s%s) ---",
                candidate.id,
                candidate.matched_metric,
                candidate.matched_term,
                " / tabla" if candidate.is_table else "",
            )
            preview = candidate.evidence.replace("\n", " ")[:_TEXT_PREVIEW_LIMIT]
            logger.info("Evidence: %s", preview)

        for group in fcf_result.evidence_groups:
            logger.info(
                "Evidence group enviada una sola vez al LLM: candidatos=%s",
                ", ".join(str(candidate_id) for candidate_id in group.candidate_ids),
            )


if __name__ == "__main__":
    main()
