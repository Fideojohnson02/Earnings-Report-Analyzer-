"""
Script de demostración del módulo de configuración y logging.

No forma parte del sistema en sí (no lo va a llamar `main.py`): existe
solo para que puedas ejecutar algo concreto ahora mismo y ver que la
infraestructura base funciona, antes de seguir con el resto del
proyecto.

Cómo ejecutarlo (parado en la carpeta raíz del proyecto):

    python -m scripts.demo_foundation
"""

from src.config.settings import get_settings
from src.logging_setup.logger import get_logger, setup_logging


def main() -> None:
    settings = get_settings()
    setup_logging(settings)

    logger = get_logger(__name__)

    logger.info("Configuración cargada correctamente.")
    logger.info("Entorno: %s", settings.environment)
    logger.info("Nivel de log configurado: %s", settings.log_level)
    logger.info("Carpeta de logs: %s", settings.log_dir)
    logger.info("Carpeta de entrada de datos: %s", settings.data_input_dir)
    logger.info("Carpeta de salida de datos: %s", settings.data_output_dir)
    logger.debug("Este mensaje de DEBUG solo se ve si LOG_LEVEL=DEBUG.")
    logger.warning("Ejemplo de advertencia (WARNING).")


if __name__ == "__main__":
    main()
